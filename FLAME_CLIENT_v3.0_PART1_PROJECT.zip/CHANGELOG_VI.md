# FLAME CLIENT — CHANGELOG

## v3.0 (versionCode 10)
- Thay nút nổi tĩnh bằng ClickGUI có thể kéo, danh mục cuộn và nút trạng thái module.
- Cấp quyền overlay xong sẽ tự hiển thị ClickGUI; service được nâng lên foreground service.
- Đồng bộ trạng thái ON/OFF với app chính; module có pack gọi luồng export/import Minecraft.
- Ghi rõ module chưa hỗ trợ runtime thay vì bật giả.

# FLAME CLIENT — Changelog

## v3.0 (versionCode 10)
- Đổi app version để APK mới không còn mang phiên bản 2.2 cũ.
- Thêm adaptive launcher icon FLAME.
- Thêm tìm kiếm trong Pack Library.
- Thêm tên file pack và bộ đếm kết quả.
- Đổi nhãn trạng thái từ ON/OFF gây hiểu nhầm sang IMPORT/SELECT.
- Thêm nút mở Minecraft và đặt lại lựa chọn trong Settings.
- Giảm nguy cơ có nhiều file export trùng tên trong Downloads.
- Thêm pre-build QA và workflow chặn source cũ.

## Giới hạn không đổi
FLAME là companion app Android. Tính năng cần hook/inject game hoặc API nội bộ không được tuyên bố hoạt động khi chưa có triển khai và kiểm thử thực tế.
