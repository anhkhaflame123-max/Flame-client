# FLAME CLIENT v3.0 — báo cáo pack

## Luồng xử lý
- Click Hub hiển thị danh sách 20 pack quick-actions và đồng bộ lựa chọn trong ứng dụng qua SharedPreferences.
- Module có pack xuất file ra `Downloads/FLAME CLIENT` trên Android 10+ rồi thử mở/import bằng Minecraft. Android cũ dùng document picker.
- Nhãn `IMPORT` khởi chạy luồng xuất/mở pack; `SELECT` có nghĩa lựa chọn đã lưu trong FLAME, không có nghĩa game đã Activate.
- Nếu pack đã Activate trong game, phải Deactivate trong Minecraft; ứng dụng đồng hành không có API công khai để tự làm việc đó.
- PACK LIBRARY hỗ trợ tìm theo tiêu đề, mô tả hoặc tên file; 20 mục catalog đã được xác minh đủ asset.

## Pack đi kèm và lưu ý
- `os_client.mcpack` — OS CLIENT HUD/UI/cosmetics; nhiều tùy chọn có thể xung đột UI.
- `gavti_pvp.mcaddon` — Behavior + Resource Pack; có dependency Script API.
- `keystrokes_cps.mcpack` — Keystrokes + CPS; có thể xung đột một CPS pack khác.
- `osk_cps.mcpack` — oSkullo CPS Counter.
- `chunkfinder.mcpack` — Chunk Finder; manifest ở gốc archive.
- `clear_glass.mcpack` — Clear & Borderless Glass; có subpacks.
- `small_items.mcpack` — kích thước vật phẩm.
- `low_fire.mcpack` — Low Fire; manifest ở gốc archive.
- `better_hands.mcpack` — Better Hands; chọn subpack Small Hand hoặc Long Hand.
- `fps_booster.mcpack` — tùy chọn animation/hiệu năng; không bảo đảm tăng FPS.
- `fps_counter.mcpack` — bộ đếm FPS dạng resource pack; chọn kích thước subpack.
- `zoom.mcaddon` — Just Zoom; có Script API dependencies, cần tương thích với phiên bản game.
- `ping_check.mcpack` — script pack yêu cầu `@minecraft/server` `3.0.0-alpha`; chưa xác nhận có HUD ping hoạt động trên Bedrock 1.26.52.
- `motion_blur.mcpack` — Simple Motion Blur; chưa thử runtime, có thể giảm hiệu năng hoặc xung đột.
- `direction_hud.mcaddon` — gói chứa hai `.mcpack` bên trong (client/server); phải đảm bảo cả phần client và behavior được import/activate.
- `custom_crosshairs.mcpack` — nhiều kiểu/màu tâm ngắm qua subpacks.
- `totem_counter.mcpack` — Offhand Totem Counter dạng extension; có thể phụ thuộc pack Utility Inventory.
- `potion_hud.mcpack` — Potion HUD.
- `slot_hotbar_button.mcpack` — thay đổi UI hotbar.
- `utility_hud.mcpack` — nhiều lựa chọn HUD, có thể xung đột UI/player packs khác.

## Module chưa có pack / chưa được tích hợp runtime
Freelook, Auto Sprint, Minimap realtime, Time Changer, Backups Manager và Coordinates HUD không điều khiển trực tiếp Minecraft từ FLAME. Các nút này không giả vờ bật thành công.

## Kiểm thử trong lần chỉnh v3.0
Script kiểm tra 20 mục catalog, file pack tồn tại và archive đọc được. XML Android được parse thành công. Chưa compile Gradle, chạy APK hoặc kiểm thử trực tiếp trong Minecraft; dependency Script API/subpack vẫn cần thử trên thiết bị.
