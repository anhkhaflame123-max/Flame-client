#!/usr/bin/env python3
"""Fail-fast source validation before the FLAME CLIENT Android build."""
from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

def require(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)

settings = ROOT / "settings.gradle.kts"
app_gradle = ROOT / "app/build.gradle.kts"
main_activity = ROOT / "app/src/main/java/com/flameclient/android/MainActivity.kt"
overlay = ROOT / "app/src/main/java/com/flameclient/android/FlameOverlayService.kt"
manifest = ROOT / "app/src/main/AndroidManifest.xml"
catalog_path = ROOT / "app/src/main/assets/packs/catalog.json"

require(settings.is_file(), "Missing settings.gradle.kts")
require(app_gradle.is_file(), "Missing app/build.gradle.kts")
require(main_activity.is_file(), "Missing MainActivity.kt")
require(overlay.is_file(), "Missing FlameOverlayService.kt")
require(manifest.is_file(), "Missing AndroidManifest.xml")
require(catalog_path.is_file(), "Missing packs/catalog.json")

if app_gradle.is_file():
    gradle_text = app_gradle.read_text(encoding="utf-8")
    require('versionCode = 10' in gradle_text, "Expected versionCode 10 (v3.0 source), refusing stale source")
    require('versionName = "3.0"' in gradle_text, "Expected versionName 3.0, refusing stale source")
if main_activity.is_file():
    code = main_activity.read_text(encoding="utf-8")
    require('PACK LIBRARY' in code, "Pack Library revision marker is missing")
    require('FLAME CLIENT v3.0' in code, "v3.0 UI marker is missing")
    require('populatePackCatalog' in code, "Pack search implementation is missing")
if overlay.is_file():
    code = overlay.read_text(encoding="utf-8")
    require('FLAME CLIENT' in code, "Overlay label is missing")
    require('dragTouch' in code, "Draggable overlay handling is missing")
    require('rebuildModules' in code, "Overlay module list is missing")
    require('ACTION_SHOW_GUI' in code, "Overlay GUI launch action is missing")
if manifest.is_file():
    manifest_text = manifest.read_text(encoding="utf-8")
    require('@mipmap/ic_launcher' in manifest_text, "Custom FLAME launcher icon is not configured")
    require('android:foregroundServiceType="specialUse"' in manifest_text, "Overlay foreground service type is missing")
    require('android.permission.FOREGROUND_SERVICE_SPECIAL_USE' in manifest_text, "Special-use foreground-service permission is missing")
require((ROOT / "app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml").is_file(), "Adaptive launcher icon resource is missing")

if catalog_path.is_file():
    try:
        entries = json.loads(catalog_path.read_text(encoding="utf-8"))
        require(isinstance(entries, list) and len(entries) == 20, "Expected 20 catalog packs")
        pack_dir = ROOT / "app/src/main/assets/packs"
        catalog_files = [entry.get("file", "") for entry in entries]
        require(len(catalog_files) == len(set(catalog_files)), "Duplicate file entries in pack catalog")
        for entry in entries:
            file_name = entry.get("file", "")
            pack_path = pack_dir / file_name
            require(bool(file_name), "Catalog entry without a file name")
            require(pack_path.is_file(), f"Catalog file is missing: {file_name}")
        # Validate every bundled archive, including any retained fallback pack not shown in the catalog.
        archive_paths = sorted(p for p in pack_dir.iterdir() if p.is_file() and p.suffix.lower() in {".mcpack", ".mcaddon"}) if pack_dir.is_dir() else []
        for pack_path in archive_paths:
            try:
                with zipfile.ZipFile(pack_path) as archive:
                    bad_member = archive.testzip()
                    require(bad_member is None, f"Corrupt archive {pack_path.name}: {bad_member}")
            except (OSError, zipfile.BadZipFile) as exc:
                errors.append(f"Invalid pack archive {pack_path.name}: {exc}")
        print(f"Pack catalog: {len(entries)} entries; {len(archive_paths)} bundled archives checked.")
    except (json.JSONDecodeError, OSError) as exc:
        errors.append(f"Could not read pack catalog: {exc}")

if errors:
    print("SOURCE VALIDATION FAILED:", file=sys.stderr)
    for error in errors:
        print(f" - {error}", file=sys.stderr)
    sys.exit(1)

print("SOURCE VALIDATION PASSED: FLAME CLIENT v3.0 / versionCode 10")
print("Required Android sources, icon resources, catalog entries, and pack archives are present.")
