# FLAME CLIENT v3.0 — Draggable ClickGUI + Pack Library

FLAME CLIENT v3.0 là ứng dụng đồng hành cho Minecraft Bedrock / PE trên Android, giữ phong cách PvP đen–đỏ–cam. Bản này thay lại floating ClickGUI: nút nổi mở menu chức năng, kéo tiêu đề để di chuyển, có danh mục, danh sách module và nút ON/OFF/ SOON rõ ràng.

## Đã sửa trong v3.0

- Thay overlay chữ tĩnh bằng ClickGUI nổi có thể kéo trên màn hình.
- Mở ClickGUI ngay sau khi cấp quyền “Hiển thị trên ứng dụng khác”; quay lại app từ màn hình cấp quyền sẽ tự bật overlay.
- Có nút thu gọn, đóng menu, mở Minecraft và nút 🔥 nổi có thể kéo.
- Có danh mục ALL / PVP / HUD / SURVIVAL / VISUAL; danh sách module cuộn được.
- Nút ON/OFF dùng chung trạng thái với ứng dụng chính. Chọn ON ở module có pack sẽ gọi lại quy trình xuất và mở pack bằng Minecraft.
- Service overlay chạy foreground kèm thông báo để giảm nguy cơ bị Android dừng khi chuyển sang Minecraft.
- Tăng `versionCode` lên **10**, `versionName` lên **3.0**.
- Giữ Java 17, Gradle 8.9, Android SDK 35 và lệnh cài SDK đang dùng.

## Cách dùng trên Samsung Galaxy A36 5G

1. Cài APK v3.0 và mở FLAME CLIENT.
2. Bấm **FLOATING GUI** hoặc **MỞ FLOATING GUI** trong SETTINGS.
3. Cấp quyền **Hiển thị trên ứng dụng khác** cho FLAME CLIENT. Bấm quay lại; ClickGUI nổi sẽ tự hiện.
4. Kéo vùng tiêu đề `FLAME CLIENT • v3.0` để di chuyển menu; kéo nút 🔥 để di chuyển nút nổi. Nút `—` thu gọn, `×` dừng overlay.
5. Bấm **MINECRAFT** để vào game trong khi ClickGUI đang chạy. Chọn module có pack và bấm ON để xuất/mở pack.
6. Trong Minecraft, chờ nhập xong; sau đó vào **Settings > Global Resources** hoặc **Resource Packs** của thế giới và Activate pack. Với `.mcaddon`, kiểm tra cả Behavior Pack và Resource Pack nếu được tạo thành hai thành phần.

Nếu overlay biến mất khi chuyển game, mở FLAME một lần nữa. Trên Samsung, có thể đặt FLAME CLIENT ở chế độ pin **Unrestricted/Không hạn chế** để hệ thống ít dừng dịch vụ nền hơn.

## Giới hạn kỹ thuật quan trọng

ClickGUI nay có thể hiển thị và di chuyển trên Minecraft, nhưng điều đó **không phải** inject/hook vào tiến trình game. Một ứng dụng Android độc lập không có API công khai để tự thay camera, hitbox, sprint, minimap, giờ thế giới hoặc tự bật/tắt resource/behavior pack trong thế giới đang chạy. Vì vậy:

- Module có file `.mcpack`/`.mcaddon`: ON trong FLAME bắt đầu quy trình xuất/mở pack; người dùng vẫn phải Activate trong Minecraft. OFF trong FLAME không tự Deactivate pack đã bật trong game.
- Module ghi **SOON** (ví dụ Freelook, Hitbox, Minimap, Time Changer, Backups Manager, Coordinates HUD) được liệt kê nhưng chưa có runtime được tích hợp; bấm vào sẽ hiện giới hạn thay vì báo ON giả.
- Pack của bên thứ ba có thể không tương thích Minecraft PE 1.26.52, có thể cần Script API/subpack hoặc xung đột nhau. Chưa thể cam kết tất cả pack hoạt động trước khi thử trực tiếp trên thiết bị/game.

## Build target

- Minecraft Bedrock / PE target: 1.26.52
- Android SDK 35 / Build Tools 35.0.0
- Java 17 / Gradle 8.9
- Application ID: `com.flameclient.android`
- App version: **3.0** (`versionCode 10`)

## Build APK qua GitHub Actions

1. Upload **cả hai** file `FLAME_CLIENT_v3.0_PART1_PROJECT.zip` và `FLAME_CLIENT_v3.0_PART2_LARGE_PACKS.zip` vào thư mục gốc repository.
2. Mở `.github/workflows/build-apk.yml`, thay toàn bộ nội dung bằng file `FLAME_CLIENT_v3.0_build-apk.yml`, rồi **Commit changes**.
3. Vào **Actions** → **Build FLAME CLIENT v3.0 APK** → **Run workflow**.
4. Chỉ tải artifact `FLAME_CLIENT-v3.0-debug-apk` của lượt chạy mới nhất và cài `FLAME_CLIENT-v3.0-debug.apk`.

Do chữ ký debug có thể khác giữa các lần build, nếu Android báo không cài được bản mới trên bản cũ, gỡ bản FLAME cũ rồi cài APK mới. Gỡ app sẽ xóa tùy chọn trong FLAME; pack đã import vào Minecraft thường vẫn nằm trong game.

## Kiểm tra source

Chạy `python3 scripts/verify_source.py`. Script xác nhận source v3.0, manifest dịch vụ overlay, danh sách 20 pack trong catalog và tính toàn vẹn các file `.mcpack`/`.mcaddon`. Môi trường tạo source này không có Android SDK/Gradle local để tuyên bố build đã thành công; GitHub Actions là bước xác nhận compile cuối cùng.
