package com.flameclient.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.min

/**
 * Floating FLAME ClickGUI for use above Minecraft Bedrock / PE.
 * The overlay itself is draggable. Pack-backed entries hand off to MainActivity
 * so the existing export/import flow is reused; Android cannot directly turn a
 * Bedrock pack on/off inside a running world.
 */
class FlameOverlayService : Service(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        private const val CHANNEL_ID = "flame_clickgui"
        private const val NOTIFICATION_ID = 3107
        const val ACTION_SHOW_GUI = "com.flameclient.android.SHOW_GUI"
    }

    private data class OverlayModule(
        val name: String,
        val category: String,
        val icon: String,
        val packFile: String? = null,
        val note: String = ""
    )

    private val modules = listOf(
        OverlayModule("Zoom", "PVP", "ZO", "zoom.mcaddon", "Import add-on; activate BP/RP in Minecraft."),
        OverlayModule("Freelook", "PVP", "FL", note = "Chưa có camera runtime độc lập cho Bedrock Android."),
        OverlayModule("Small Hand", "PVP", "SH", "better_hands.mcpack", "Chọn subpack Small Hand trong Minecraft."),
        OverlayModule("Big Hand", "PVP", "BH", "better_hands.mcpack", "Chọn subpack Long Hand trong Minecraft."),
        OverlayModule("FPS Booster", "PVP", "FB", "fps_booster.mcpack", "Tác dụng FPS phụ thuộc pack và cấu hình máy."),
        OverlayModule("FPS Counter", "PVP", "FP", "fps_counter.mcpack", "Chọn subpack bộ đếm trong Minecraft."),
        OverlayModule("Ping Counter", "PVP", "PI", "ping_check.mcpack", "Phụ thuộc Script API; chưa xác minh trên 1.26.52."),
        OverlayModule("CPS Counter", "PVP", "CP", "osk_cps.mcpack", "HUD pack bên thứ ba; cần Activate trong game."),
        OverlayModule("Motion Blur", "PVP", "MB", "motion_blur.mcpack", "Có thể giảm FPS hoặc xung đột render."),
        OverlayModule("Crosshair Customizer", "PVP", "CH", "custom_crosshairs.mcpack", "Chọn subpack crosshair trong Minecraft."),
        OverlayModule("Totem Counter", "PVP", "TC", "totem_counter.mcpack", "Có thể cần pack Utility Inventory tương thích."),
        OverlayModule("Hitbox", "PVP", "HB", note = "Chưa có module hitbox runtime trong app."),
        OverlayModule("Utility HUD", "HUD", "UH", "utility_hud.mcpack", "Chọn subpack; có thể xung đột HUD khác."),
        OverlayModule("Potion Status", "SURVIVAL", "PS", "potion_hud.mcpack", "Cần thử trên phiên bản game mục tiêu."),
        OverlayModule("Minimap", "SURVIVAL", "MM", note = "Chưa có minimap thời gian thực được tích hợp."),
        OverlayModule("Chunk Finder", "SURVIVAL", "CF", "chunkfinder.mcpack", "Import và Activate resource pack trong game."),
        OverlayModule("Time Changer", "SURVIVAL", "TM", note = "Chưa điều khiển thời gian thế giới từ app."),
        OverlayModule("Backups Manager", "SURVIVAL", "BK", note = "Chưa được kết nối với dữ liệu world."),
        OverlayModule("Coordinates HUD", "HUD", "XY", note = "Chưa có pack tọa độ thời gian thực tích hợp."),
        OverlayModule("Keystrokes", "HUD", "KS", "keystrokes_cps.mcpack", "Chọn subpack; tránh bật hai CPS pack cùng lúc."),
        OverlayModule("Direction HUD", "HUD", "DH", "direction_hud.mcaddon", "Add-on gồm các thành phần client/server."),
        OverlayModule("Hotbar Button", "HUD", "HB", "slot_hotbar_button.mcpack", "Thay đổi UI hotbar sau khi pack được bật."),
        OverlayModule("Crosshair Style", "VISUAL", "CS", "gavti_pvp.mcaddon", "Add-on bên thứ ba; dependency chưa xác minh."),
        OverlayModule("OS CLIENT Pack", "VISUAL", "OS", "os_client.mcpack", "Pack giao diện lớn; có thể xung đột UI."),
        OverlayModule("Low Fire", "VISUAL", "LF", "low_fire.mcpack"),
        OverlayModule("Clear Glass", "VISUAL", "CG", "clear_glass.mcpack", "Chọn subpack nếu pack yêu cầu."),
        OverlayModule("Small Items", "VISUAL", "SI", "small_items.mcpack", "Thu nhỏ item; không phải đổi kích thước bàn tay."),
    )

    private val colorBg = Color.rgb(12, 10, 13)
    private val colorPanel = Color.rgb(29, 23, 26)
    private val colorStroke = Color.rgb(103, 48, 37)
    private val colorRed = Color.rgb(225, 43, 34)
    private val colorOrange = Color.rgb(255, 127, 43)
    private val colorWhite = Color.rgb(249, 244, 242)
    private val colorMuted = Color.rgb(177, 163, 164)

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: SharedPreferences
    private var launcherView: View? = null
    private var guiView: View? = null
    private var guiParams: WindowManager.LayoutParams? = null
    private var moduleContainer: LinearLayout? = null
    private var categoryContainer: LinearLayout? = null
    private var enabledCountText: TextView? = null
    private var selectedCategory = "ALL"

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(this)
        startAsForegroundService()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW_GUI) {
            showGui()
        } else if (guiView == null && launcherView == null) {
            showLauncher()
        }
        return START_STICKY
    }

    private fun startAsForegroundService() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "FLAME ClickGUI", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Keeps the user-enabled FLAME floating menu available over Minecraft."
                    setShowBadge(false)
                }
            )
        }
        val openApp = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val pending = PendingIntent.getActivity(
            this, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("FLAME CLIENT đang chạy")
            .setContentText("Chạm để mở app • Nút 🔥 nổi để mở ClickGUI")
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
    }

    private fun showLauncher() {
        if (launcherView != null) return
        val bubble = TextView(this).apply {
            text = "🔥"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(colorWhite)
            background = rounded(colorRed, colorOrange, 18)
            elevation = dp(8).toFloat()
            contentDescription = "Mở FLAME ClickGUI; kéo để di chuyển"
            setOnClickListener { showGui() }
        }
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            dp(54), dp(54), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(140)
        }
        bubble.setOnTouchListener(dragTouch(bubble, params, onTap = { showGui() }))
        try {
            windowManager.addView(bubble, params)
            launcherView = bubble
        } catch (e: Exception) {
            Toast.makeText(this, "Không thể hiện nút nổi. Kiểm tra quyền hiển thị trên ứng dụng khác.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun showGui() {
        if (guiView != null) return
        removeLauncher()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(colorBg, colorRed, 16)
            elevation = dp(12).toFloat()
        }

        val heightDp = (resources.displayMetrics.heightPixels / resources.displayMetrics.density * 0.70f).toInt()
        val params = makeGuiParams().apply {
            width = dp(300)
            height = dp(min(530, heightDp.coerceAtLeast(330)))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(4), dp(3), dp(7))
        }
        val title = TextView(this).apply {
            text = "🔥 FLAME CLIENT  •  v3.0"
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(colorOrange)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(7), dp(5), dp(7))
            contentDescription = "Kéo vùng tiêu đề để di chuyển ClickGUI"
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(39), 1f))
        val minimize = button("—", colorPanel, colorWhite, 12f) { hideGuiAndRestoreLauncher() }
        header.addView(minimize, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginStart = dp(3) })
        val close = button("×", colorRed, colorWhite, 18f) { stopSelf() }
        header.addView(close, LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginStart = dp(3) })
        root.addView(header)

        title.setOnTouchListener(dragTouch(title, params, onTap = {}, windowView = root))

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = rounded(colorPanel, colorStroke, 10)
        }
        statusRow.addView(label("MODULES", 10f, colorWhite, true), LinearLayout.LayoutParams(0, dp(22), 1f))
        enabledCountText = label("0 SELECTED", 9f, colorOrange, true)
        statusRow.addView(enabledCountText)
        root.addView(statusRow, margin(bottom = 7))

        val categoriesScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
        }
        categoryContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        categoriesScroll.addView(categoryContainer)
        root.addView(categoriesScroll, margin(bottom = 7))

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        moduleContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(moduleContainer)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(7), 0, 0)
        }
        footer.addView(button("MINECRAFT ↗", colorRed, colorWhite, 10f) { openMinecraft() }, LinearLayout.LayoutParams(0, dp(36), 1f))
        footer.addView(button("HIDE", colorPanel, colorOrange, 10f) { hideGuiAndRestoreLauncher() }, LinearLayout.LayoutParams(dp(70), dp(36)).apply { marginStart = dp(6) })
        root.addView(footer)

        try {
            windowManager.addView(root, params)
            guiView = root
            guiParams = params
            rebuildCategories()
            rebuildModules()
        } catch (e: Exception) {
            guiView = null
            guiParams = null
            Toast.makeText(this, "Không mở được ClickGUI: kiểm tra quyền overlay.", Toast.LENGTH_LONG).show()
            showLauncher()
        }
    }

    private fun rebuildCategories() {
        val container = categoryContainer ?: return
        container.removeAllViews()
        listOf("ALL", "PVP", "HUD", "SURVIVAL", "VISUAL").forEach { category ->
            val selected = category == selectedCategory
            container.addView(
                button(category, if (selected) colorRed else colorPanel, if (selected) colorWhite else colorMuted, 9f) {
                    selectedCategory = category
                    rebuildCategories()
                    rebuildModules()
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)).apply {
                    marginEnd = dp(5)
                }
            )
        }
    }

    private fun rebuildModules() {
        val container = moduleContainer ?: return
        container.removeAllViews()
        val enabled = modules.count { it.packFile != null && prefs.getBoolean(prefKey(it), false) }
        enabledCountText?.text = "$enabled ON"

        val visible = if (selectedCategory == "ALL") modules else modules.filter { it.category == selectedCategory }
        visible.forEach { module ->
            val isEnabled = module.packFile != null && prefs.getBoolean(prefKey(module), false)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(7), dp(7), dp(7), dp(7))
                background = rounded(colorPanel, if (isEnabled) colorOrange else colorStroke, 10)
            }
            val icon = TextView(this).apply {
                text = module.icon
                textSize = 9f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(if (isEnabled) colorWhite else colorOrange)
                background = rounded(if (isEnabled) Color.rgb(103, 38, 27) else Color.rgb(42, 29, 30), colorStroke, 8)
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(35), dp(35)).apply { marginEnd = dp(7) })

            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(label(module.name, 11f, colorWhite, true))
            val detailText = when {
                module.packFile == null -> "CHƯA TÍCH HỢP • ${module.category}"
                isEnabled -> "ĐÃ CHỌN • CẦN ACTIVATE TRONG GAME"
                else -> module.category
            }
            labels.addView(label(detailText, 8f, if (module.packFile == null) colorMuted else colorOrange).apply {
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val toggleText = if (isEnabled) "ON" else "OFF"
            val toggleFill = if (isEnabled) Color.rgb(177, 51, 23) else Color.rgb(48, 39, 41)
            row.addView(
                button(toggleText, toggleFill, if (module.packFile == null) colorMuted else colorWhite, 10f) {
                    toggleModule(module)
                },
                LinearLayout.LayoutParams(dp(48), dp(34)).apply { marginStart = dp(5) }
            )
            container.addView(row, margin(bottom = 5))
        }
        val hint = TextView(this).apply {
            text = "ON = đã chọn/xuất pack, chưa xác nhận Minecraft đã Activate. OFF màu xám = module chưa có runtime game."
            textSize = 9f
            setTextColor(colorMuted)
            setPadding(dp(4), dp(5), dp(4), dp(6))
        }
        container.addView(hint)
    }

    private fun toggleModule(module: OverlayModule) {
        val packFile = module.packFile
        if (packFile == null) {
            Toast.makeText(this, "${module.name} chưa có runtime game. ${module.note}", Toast.LENGTH_LONG).show()
            return
        }

        val key = prefKey(module)
        val wasEnabled = prefs.getBoolean(key, false)
        if (wasEnabled) {
            prefs.edit().putBoolean(key, false).apply()
            Toast.makeText(this, "Đã chuyển ${module.name} về OFF trong FLAME. Nếu pack đang chạy, hãy Deactivate trong Minecraft.", Toast.LENGTH_LONG).show()
            rebuildModules()
            return
        }

        val editor = prefs.edit().putBoolean(key, true)
        if (module.name == "Keystrokes") editor.putBoolean("module_CPS Counter", false)
        if (module.name == "CPS Counter") editor.putBoolean("module_Keystrokes", false)
        if (module.name == "Small Hand") editor.putBoolean("module_Big Hand", false)
        if (module.name == "Big Hand") editor.putBoolean("module_Small Hand", false)
        editor.apply()
        rebuildModules()
        openPackFlow(module)
    }

    private fun openPackFlow(module: OverlayModule) {
        val packFile = module.packFile ?: return
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_EXPORT_PACK, packFile)
            putExtra(MainActivity.EXTRA_MODULE_NAME, module.name)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Mở FLAME để xuất pack ${module.name}: ${e.message ?: "Android chặn mở màn hình"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openMinecraft() {
        val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launch == null) {
            Toast.makeText(this, "Chưa tìm thấy Minecraft Bedrock/PE trên máy.", Toast.LENGTH_LONG).show()
            return
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { startActivity(launch) }.onFailure {
            Toast.makeText(this, "Không mở được Minecraft: ${it.message ?: "lỗi hệ thống"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun hideGuiAndRestoreLauncher() {
        removeGui()
        showLauncher()
    }

    private fun removeLauncher() {
        launcherView?.let { runCatching { windowManager.removeView(it) } }
        launcherView = null
    }

    private fun removeGui() {
        guiView?.let { runCatching { windowManager.removeView(it) } }
        guiView = null
        guiParams = null
        moduleContainer = null
        categoryContainer = null
        enabledCountText = null
    }

    private fun makeGuiParams() = WindowManager.LayoutParams(
        dp(300), dp(500),
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(12)
        y = dp(90)
    }

    private fun dragTouch(
        view: View,
        params: WindowManager.LayoutParams,
        onTap: () -> Unit,
        windowView: View = view
    ): View.OnTouchListener {
        var downRawX = 0f
        var downRawY = 0f
        var originalX = 0
        var originalY = 0
        var moved = false
        val moveThreshold = dp(5)
        return View.OnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    originalX = params.x
                    originalY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (abs(dx) > moveThreshold || abs(dy) > moveThreshold) moved = true
                    if (moved) {
                        params.x = originalX + dx.toInt()
                        params.y = originalY + dy.toInt()
                        runCatching { windowManager.updateViewLayout(windowView, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (view === launcherView) {
                            view.performClick()
                        } else {
                            onTap()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
    }

    private fun button(text: String, fill: Int, textColor: Int, size: Float, click: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(textColor)
        gravity = Gravity.CENTER
        setPadding(dp(7), dp(5), dp(7), dp(5))
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        background = rounded(fill, if (fill == colorRed || fill == colorOrange) colorOrange else colorStroke, 8)
        isClickable = true
        isFocusable = false
        setOnClickListener { click() }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun margin(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }

    private fun prefKey(module: OverlayModule) = "module_${module.name}"
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        if (key?.startsWith("module_") == true) rebuildModules()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(this)
        removeGui()
        removeLauncher()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
