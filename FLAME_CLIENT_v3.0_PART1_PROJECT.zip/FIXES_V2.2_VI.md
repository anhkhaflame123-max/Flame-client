# FLAME CLIENT v2.2 — các chỉnh sửa trong bản này

## Đã sửa trong mã nguồn
- Các module có pack kèm theo có thể mở thông tin module và bấm `XUẤT PACK` ngay tại đó: Chunk Finder, Keystrokes/CPS, Low Fire, Clear Glass, Small Items/Small Hand.
- Trạng thái module dùng SharedPreferences có tên riêng của ứng dụng thay vì preference riêng theo Activity.
- Menu nổi mở đúng tab: ClickGUI → MODULES; Chunk Borders → PACKS; FPS Setup → SETTINGS; Crosshair/PvP → MODULES/PVP.
- Cập nhật mô tả để phân biệt pack có sẵn với tính năng chưa có tích hợp trực tiếp trong Minecraft.

## Giới hạn cần nói rõ
- Android app độc lập không thể tự thay đổi camera, đọc FPS/ping, trạng thái giáp/toạ độ hoặc điều khiển module bên trong Minecraft Bedrock chỉ bằng một công tắc.
- Những pack được xuất phải được nhập/bật trong Minecraft; app không thể tự bật chúng trong game.
- Freelook, Motion Blur, Minimap thời gian thực, FPS/Ping counter thật và nhiều HUD runtime vẫn cần một cơ chế tích hợp Minecraft tương thích riêng. Bản này không giả vờ các tính năng đó đã hoạt động.

## Build / kiểm tra
- Giữ nguyên `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts`, `.github/workflows/build-apk.yml`, cấu hình SDK, Java và Gradle.
- Các file pack trong assets đã được kiểm tra là ZIP hợp lệ và chứa `manifest.json`.
- Chưa xác nhận build APK trong môi trường này vì không có lệnh `gradle` cài sẵn; hãy chạy workflow hiện có để xác nhận build cuối cùng.
