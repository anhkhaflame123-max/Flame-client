# FLAME CLIENT 1.3 — báo cáo tích hợp pack

Bản này đóng gói riêng các pack do người dùng cung cấp vào `app/src/main/assets/packs/` và thêm danh sách xuất pack trong ứng dụng. Ứng dụng không tự cài pack vào Minecraft; người dùng chọn Xuất/Mở, lưu file, rồi nhập và kích hoạt trong Minecraft.

## Pack đi kèm
- **OS CLIENT • HUD / cosmetics / UI** (`os_client.mcpack`): Pack lớn; cần kiểm tra giấy phép và xung đột HUD.
- **GAVTI PvP Pack • BP + RP** (`gavti_pvp.mcaddon`): Có Behavior Pack và script; cần bật pack trong thế giới và thử tương thích.
- **Keystrokes + CPS Counter** (`keystrokes_cps.mcpack`): Có subpack Keystrokes + CPS hoặc CPS.
- **oSkullo's CPS Counter** (`osk_cps.mcpack`): HUD CPS dựa trên hoạt ảnh vung tay.
- **Bedrock ChunkFinder v1.2.0** (`chunkfinder.mcpack`): Pack ranh giới chunk/slime chunk; min engine 1.26.0.
- **Clear & Borderless Glass** (`clear_glass.mcpack`): Chọn subpack trong Minecraft.
- **Small Items** (`small_items.mcpack`): Chọn subpack kích thước vật phẩm trong Minecraft.
- **Low Fire** (`low_fire.mcpack`): Pack Low Fire đã gửi trước đó.

## Xung đột và giới hạn
- Không gộp các pack thành một resource pack, vì nhiều pack cùng sửa entity/player HUD hoặc tài nguyên chung.
- Keystrokes+CPS và oSkullo CPS Counter có thể xung đột vì cả hai sửa `entity/player.entity.json`. Chỉ bật một pack HUD tương ứng để thử.
- PvP Pack có Behavior Pack + script; cần bật Experimental/API phù hợp nếu Minecraft yêu cầu. Chưa xác minh runtime trên 1.26.52.
- OS CLIENT là pack bên thứ ba; giữ nguyên nội dung và ghi nhận tác giả. Kiểm tra giấy phép trước khi phân phối công khai.
- APK chưa được build hoặc kiểm thử trong Minecraft ở môi trường này. Đây là source project để build.


## Các pack bổ sung trong bản tổng hợp v1.6
- **FPS Booster v2.2 Stable** (`FPS Booster v2.2 stable.mcpack`): Tối ưu hiệu năng; cần kiểm tra thực tế trên 1.26.52.
- **Better Hands V3.2** (`Better_Hands_V3.2.mcpack`): Tùy chỉnh tay góc nhìn thứ nhất.
- **FPS Counter Rut V1.1** (`FPS_Counter_Rut_V-1.1.mcpack`): Hiển thị FPS/ms; có tùy chọn kích thước.
- **Potion HUD by Rajdeep** (`Potion HUD by Rajdeep.mcpack`): Hiển thị HUD hiệu ứng thuốc.
- **Slot Hotbar Button V1.3.1** (`Slot Hotbar Button v1.3.1.mcpack`): Tùy chỉnh nút hotbar.
- **Custom Crosshairs 5.1.0** (`Custom Crosshairs 5.1.0.mcpack`): Các kiểu tâm ngắm tùy chỉnh.
- **Offhand Totem Counter (Ext. UI)** (`Offhand Totem Counter (Ext. UI).mcpack`): Phần mở rộng; có thể yêu cầu pack gốc Utility Inventory.
- **Utility HUD** (`utility-hud.mcpack`): Nhiều mô-đun HUD; có thể trùng chức năng với pack khác.
- **Motion Blur** (`motion_blur.mcpack`): Hiệu ứng motion blur; cần kiểm tra hiển thị.
- **Custom Crosshairs 5.1.0 (bản trùng)** (`Custom Crosshairs 5.1.0(1).mcpack`): Bản trùng tên/nội dung có thể có; không bật đồng thời với bản còn lại.
- **Direction HUD** (`DIRECTION HUD.mcaddon`): HUD hướng; file addon.
- **Player Ping Check V1.0.0** (`Player Ping Check v1.0.0.mcaddon`): Công cụ kiểm tra ping người chơi.
- **Just Zoom V1.2.1** (`(E) Just Zoom v1.2.1.mcaddon`): Zoom pack.
- **EWM Stable V1.3.1 Achievements** (`EWM STABLE V1.3.1 ACHIEVEMENTS.mcaddon`): Bản đồ thế giới/minimap; có thể xung đột với pack bản đồ khác.

Tổng số file pack trong thư mục assets (không tính catalog.json): 23.
Lưu ý: ứng dụng chỉ đóng gói và xuất file pack; không tự cài vào Minecraft hay đảm bảo mọi pack hoạt động đồng thời. Hãy thử từng pack và sao lưu thế giới trước.
