# FLAME CLIENT v2.2 — bộ nguồn đã tách để build

- ZIP này chỉ chứa project FLAME CLIENT và workflow build; APK Flarial không nằm trong project build.
- Workflow tìm Gradle root từ repository root hoặc thư mục con, rồi build `:app:assembleDebug`.
- Java 17, Gradle 8.9 và bộ Android SDK packages được giữ nguyên: `platform-tools`, `platforms;android-35`, `build-tools;35.0.0`.

## Cách dùng trên GitHub điện thoại
1. Giải nén ZIP này trên máy/ứng dụng quản lý file.
2. Upload các file/thư mục bên trong vào repository FLAME CLIENT (để `.github/workflows/build-apk.yml` giữ đúng đường dẫn). Không upload APK Flarial vào thư mục project.
3. Commit thay đổi.
4. Vào **Actions → Build FLAME CLIENT APK → Run workflow**.
5. Khi chạy thành công, tải artifact `FLAME_CLIENT-v2.2-debug-apk`.

## Lưu ý
Đây là bộ nguồn/workflow được chuẩn bị để build; chưa có xác nhận build thành công trên GitHub. Các tính năng yêu cầu Minecraft có thể vẫn cần bật resource pack riêng trong game.
