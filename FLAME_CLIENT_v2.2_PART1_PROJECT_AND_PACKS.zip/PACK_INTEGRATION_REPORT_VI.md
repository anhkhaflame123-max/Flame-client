# FLAME CLIENT v2.2 — báo cáo tích hợp pack

## Luồng điều khiển
- Click Hub hiển thị danh sách cuộn 20 pack-backed toggles, đồng bộ trạng thái lựa chọn với tab MODULES bằng SharedPreferences.
- Bật module lưu file vào `Downloads/FLAME CLIENT` trên Android 10+ rồi thử mở/import qua Minecraft. Android cũ dùng bộ chọn tài liệu.
- OFF chỉ tắt trạng thái chọn của FLAME. Resource/Behavior Pack đã được Activate vẫn phải tự Deactivate trong Minecraft; đây là giới hạn của ứng dụng đồng hành độc lập.
- Catalog có 20 mục duy nhất. Có giữ asset ChunkFinder nguyên bản như bản dự phòng, nhưng chỉ liệt kê một bản đã chuẩn hóa trong catalog.

## Pack đi kèm và lưu ý
- `os_client.mcpack` — OS CLIENT HUD/UI/cosmetics; nhiều tùy chọn có thể xung đột UI.
- `gavti_pvp.mcaddon` — Behavior + Resource Pack; có dependency Script API.
- `keystrokes_cps.mcpack` — Keystrokes + CPS; có thể xung đột một CPS pack khác.
- `osk_cps.mcpack` — oSkullo CPS Counter.
- `chunkfinder.mcpack` — Chunk Finder; manifest ở gốc archive.
- `clear_glass.mcpack` — Clear & Borderless Glass; có subpacks.
- `small_items.mcpack` — kích thước vật phẩm.
- `low_fire.mcpack` — Low Fire; manifest ở gốc archive.
- `better_hands.mcpack` — Better Hands; chọn subpack Small Hand hoặc Long Hand.
- `fps_booster.mcpack` — lựa chọn animation/hiệu năng; không bảo đảm tăng FPS.
- `fps_counter.mcpack` — bộ đếm FPS dạng resource pack; chọn kích thước subpack.
- `zoom.mcaddon` — Just Zoom; có Script API dependencies, cần tương thích với phiên bản game.
- `ping_check.mcpack` — script pack yêu cầu `@minecraft/server` `3.0.0-alpha`; chưa xác nhận có HUD ping hoạt động trên Bedrock 1.26.52.
- `motion_blur.mcpack` — Simple Motion Blur; chưa thử runtime, có thể giảm hiệu năng hoặc xung đột.
- `direction_hud.mcaddon` — gói chứa hai `.mcpack` bên trong (client/server); phải đảm bảo cả phần client và behavior được import/activate.
- `custom_crosshairs.mcpack` — nhiều kiểu/màu tâm ngắm qua subpacks.
- `totem_counter.mcpack` — Offhand Totem Counter dạng extension; có thể phụ thuộc pack Utility Inventory.
- `potion_hud.mcpack` — Potion HUD.
- `slot_hotbar_button.mcpack` — thay đổi UI hotbar.
- `utility_hud.mcpack` — nhiều lựa chọn HUD, có thể xung đột `player.entity.json`/UI của pack khác.

## Những module không có pack tương ứng
Freelook, Auto Sprint, Minimap realtime, Time Changer, Backups Manager, Coordinates HUD vẫn giữ trạng thái OFF khi bấm bật. Không có đường tích hợp runtime trực tiếp để app tự đọc/điều khiển Minecraft chỉ từ công tắc Android.

## Kiểm thử
Đã kiểm tra JSON catalog, sự tồn tại của các asset, cấu trúc ZIP, và manifest cho các `.mcpack`. Chưa compile Gradle, chạy APK hoặc kiểm thử trực tiếp trong Minecraft; phụ thuộc Script API/subpack vẫn cần thử trên thiết bị.
