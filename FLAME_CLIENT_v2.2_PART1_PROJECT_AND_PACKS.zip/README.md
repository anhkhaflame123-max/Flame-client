# FLAME CLIENT v2.2 — Click Hub + Pack Import (Android source)

FLAME CLIENT là ứng dụng Android đồng hành cho Minecraft Bedrock / PE, với giao diện đen–đỏ–cam và Floating Click Hub. Đây **không phải client được inject vào Minecraft**: Android không cung cấp API công khai để ứng dụng độc lập tự bật/tắt Resource/Behavior Pack trong thế giới đang chạy.

## Những thay đổi trong bản Click Hub + Pack Import Fix
- Floating Click Hub có danh sách cuộn với 20 nút nhanh cho pack được tích hợp vào APK.
- Bấm ON sẽ lưu lựa chọn ở FLAME, xuất pack vào `Downloads/FLAME CLIENT` trên Android 10+ và thử chuyển thẳng sang Minecraft; Android cũ dùng bộ chọn file.
- Bấm OFF tắt trạng thái chọn trong FLAME. Nếu pack đã được Activate bên trong Minecraft, phải Deactivate trong Minecraft — ứng dụng ngoài không thể tự làm điều đó.
- MainActivity và Click Hub dùng chung SharedPreferences để đồng bộ trạng thái.
- Trang PACKS có 20 mục và các mô tả cảnh báo về phụ thuộc API, subpack và xung đột có thể có.
- Đã chuẩn hóa một số archive để `manifest.json` nằm ở gốc `.mcpack`, đồng thời giữ ghi chú bên thứ ba.
- Android 10+ dùng MediaStore để tránh trình chọn “Save As” trắng/khó hiểu; app thử MIME `.mcpack`/`.mcaddon` dành riêng cho Minecraft rồi fallback sang bộ mở file hệ thống.
- Giữ nguyên các file cấu hình Gradle/Java/SDK/workflow; Manifest chỉ khai báo visibility cho package Minecraft để kiểm tra trình nhập.

## Cách dùng
1. Mở FLAME > bật Floating GUI; chạm nút 🔥 FLAME để mở Click Hub.
2. Bật một module có pack. App sẽ lưu file và thử mở Minecraft để import.
3. Khi Minecraft báo import xong, vào **Settings > Global Resources** hoặc cài đặt thế giới để Activate Resource Pack. Với `.mcaddon`, bật cả Behavior Pack và Resource Pack nếu có.
4. Một số pack cần chọn subpack trong cài đặt pack. Xem tab PACKS để đọc lưu ý cụ thể.
5. Để tắt hiệu lực trong game, Deactivate pack trong Minecraft. OFF trong Click Hub chỉ thay đổi lựa chọn trong ứng dụng.

## Giới hạn
Freelook, minimap/tọa độ thời gian thực, time changer, backups và auto sprint chưa được tích hợp trực tiếp. Pack như FPS Counter, Ping Check, Zoom add-on, Totem Counter hoặc Motion Blur có thể không tương thích với bản game/API mục tiêu; chúng được ghi rõ là chưa kiểm thử, không cam kết chạy.

## Build target
- Minecraft Bedrock / PE target: 1.26.52
- Android SDK 35 / Build Tools 35.0.0
- Java 17 / Gradle 8.9
- Application ID: `com.flameclient.android`

**Chưa build APK hoặc kiểm thử trên Samsung Galaxy A36 5G/Minecraft trong môi trường sửa này.** Đây là source ZIP để chạy qua workflow build hiện có, không phải APK đã xác minh.
