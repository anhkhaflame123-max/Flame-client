package com.flameclient.android

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

/**
 * FLAME CLIENT mobile ClickGUI.
 * The screen uses a Flarial-inspired client layout pattern while keeping original FLAME styling.
 * Pack-backed modules can export/import a compatible Bedrock pack. Android cannot directly
 * activate/deactivate packs inside a world, so Minecraft still requires an explicit activation.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 13)
    private val panel = Color.rgb(23, 20, 23)
    private val panelRaised = Color.rgb(31, 25, 27)
    private val border = Color.rgb(74, 39, 35)
    private val red = Color.rgb(255, 59, 45)
    private val orange = Color.rgb(255, 129, 43)
    private val white = Color.rgb(247, 243, 242)
    private val muted = Color.rgb(166, 157, 159)
    private val greenOn = Color.rgb(255, 103, 43)
    private val createPackFile = 7201

    companion object {
        const val PREFS_NAME = "flame_client_preferences"
        const val EXTRA_OPEN_SECTION = "com.flameclient.android.OPEN_SECTION"
        const val EXTRA_OPEN_CATEGORY = "com.flameclient.android.OPEN_CATEGORY"
        const val EXTRA_EXPORT_PACK = "com.flameclient.android.EXPORT_PACK"
        const val EXTRA_MODULE_NAME = "com.flameclient.android.MODULE_NAME"
    }

    private var pendingPack = ""
    private var pendingModuleName = ""
    private var selectedCategory = "PVP"
    private var selectedSection = "MODULES"
    private var searchText = ""
    private lateinit var moduleList: LinearLayout
    private var activeCountBadge: TextView? = null

    private val categories = listOf("PVP", "SINH TỒN", "HUD", "VISUAL")
    private val modules = listOf(
        Module("Zoom", "Just Zoom add-on (BP + RP); yêu cầu Minecraft hỗ trợ Script API tương ứng", "PVP", "ZO", "zoom.mcaddon"),
        Module("Freelook", "Chưa có camera độc lập tương thích Bedrock Android", "PVP", "FL"),
        Module("Small Hand", "Better Hands: sau khi nhập, chọn subpack Small Hand trong cài đặt Resource Pack", "PVP", "SH", "better_hands.mcpack"),
        Module("FPS Booster", "Resource pack tối ưu animation; FPS thực tế tùy máy, không bảo đảm tăng FPS", "PVP", "FB", "fps_booster.mcpack"),
        Module("FPS Counter", "Resource pack hiển thị FPS; chọn kích cỡ subpack sau khi nhập", "PVP", "FP", "fps_counter.mcpack"),
        Module("Ping Counter", "Pack script yêu cầu @minecraft/server 3.0.0-alpha; tương thích và HUD chưa được kiểm chứng", "PVP", "PI", "ping_check.mcpack"),
        Module("CPS Counter", "oSkullo CPS Counter; đây là HUD pack, không phải kết nối dữ liệu hệ thống của FLAME", "PVP", "CP", "osk_cps.mcpack"),
        Module("Motion Blur", "Resource pack Motion Blur; hiệu ứng và khả năng tương thích cần thử trong game", "PVP", "MB", "motion_blur.mcpack"),
        Module("Crosshair Customizer", "Custom Crosshairs; chọn hình dạng/màu trong subpacks của resource pack", "PVP", "CH", "custom_crosshairs.mcpack"),
        Module("Totem Counter", "Offhand Totem Counter (Ext. UI) có thể cần pack Utility Inventory tương thích", "PVP", "TC", "totem_counter.mcpack"),
        Module("Utility HUD", "Gói HUD nhiều lựa chọn như armor/utility; có thể xung đột HUD hoặc player UI pack khác", "HUD", "UH", "utility_hud.mcpack"),
        Module("Auto Sprint HUD", "Chưa điều khiển chuyển động nhân vật trong Minecraft", "PVP", "AS"),
        Module("Potion Status", "Potion HUD resource pack; kiểm tra giao diện trong phiên bản game đang dùng", "SINH TỒN", "PS", "potion_hud.mcpack"),
        Module("Minimap", "Chưa có minimap thời gian thực được xác minh cho Bedrock Android", "SINH TỒN", "MM"),
        Module("Chunk Finder", "Bedrock Chunk Finder; nhập và Activate trong Minecraft", "SINH TỒN", "CF", "chunkfinder.mcpack"),
        Module("Time Changer", "Chưa thay đổi thời gian thế giới từ app", "SINH TỒN", "TM"),
        Module("Backups Manager", "Chưa được kết nối với dữ liệu thế giới Minecraft", "SINH TỒN", "BK"),
        Module("Coordinates HUD", "Chưa có pack tọa độ độc lập được xác minh trong bộ này", "HUD", "XY"),
        Module("Keystrokes", "Keystrokes + CPS resource pack; có thể xung đột với một CPS pack khác", "HUD", "KS", "keystrokes_cps.mcpack"),
        Module("Direction HUD", "Add-on gồm client resource pack và server behavior pack; nhập cả hai thành phần", "HUD", "DH", "direction_hud.mcaddon"),
        Module("Hotbar Button", "Slot Hotbar Button; ảnh hưởng thành phần UI hotbar khi resource pack được Activate", "HUD", "HB", "slot_hotbar_button.mcpack"),
        Module("Crosshair Style", "Gavti PvP add-on gồm BP/RP; có thể có phụ thuộc script/API", "VISUAL", "CS", "gavti_pvp.mcaddon"),
        Module("OS CLIENT Pack", "Pack lớn gồm UI/cosmetics; không bảo đảm có minimap thời gian thực", "VISUAL", "OS", "os_client.mcpack"),
        Module("Low Fire", "Low Fire resource pack", "VISUAL", "LF", "low_fire.mcpack"),
        Module("Clear Glass", "Clear & Borderless Glass; chọn subpack trong Minecraft nếu có", "VISUAL", "CG", "clear_glass.mcpack"),
        Module("Small Items", "Resource pack thu nhỏ vật phẩm; không giống Small Hand", "VISUAL", "SI", "small_items.mcpack")
    )
    private data class Module(val name: String, val detail: String, val category: String, val icon: String, val packFile: String? = null, val packMime: String = "application/octet-stream")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = 0
        handleRouteIntent(intent)
    }

    override fun onNewIntent(newIntent: Intent?) {
        super.onNewIntent(newIntent)
        if (newIntent == null) return
        setIntent(newIntent)
        handleRouteIntent(newIntent)
    }

    private fun handleRouteIntent(routeIntent: Intent) {
        selectedSection = routeIntent.getStringExtra(EXTRA_OPEN_SECTION) ?: selectedSection
        selectedCategory = routeIntent.getStringExtra(EXTRA_OPEN_CATEGORY) ?: selectedCategory
        render()
        val routePack = routeIntent.getStringExtra(EXTRA_EXPORT_PACK)
        val routeModule = routeIntent.getStringExtra(EXTRA_MODULE_NAME).orEmpty()
        if (!routePack.isNullOrBlank()) {
            window.decorView.post {
                exportPack(routePack, "application/octet-stream", routeModule)
            }
        }
    }

    private fun render() {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(10))
            setBackgroundColor(bg)
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brandStack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brandStack.addView(text("🔥 FLAME CLIENT", 24f, orange, true))
        brandStack.addView(text("BEDROCK / PE 1.26.52  •  MOBILE", 10f, muted, true).apply {
            setPadding(dp(1), dp(3), 0, 0)
        })
        brandRow.addView(brandStack, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        brandRow.addView(pill("FLOATING GUI", panelRaised, orange, 10f) { requestOverlay() })
        shell.addView(brandRow, margin(bottom = 13))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = rounded(panel, border, 13)
        }
        val sections = listOf("MODULES", "PACKS", "SETTINGS")
        sections.forEach { section ->
            nav.addView(pill(section, if (selectedSection == section) red else panel,
                if (selectedSection == section) white else muted, 11f, true) {
                selectedSection = section
                render()
            }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(3); marginStart = dp(3) })
        }
        shell.addView(nav, margin(bottom = 10))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(bg)
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, dp(12))
        }
        when (selectedSection) {
            "MODULES" -> renderClickGui(body)
            "PACKS" -> renderPacks(body)
            else -> renderSettings(body)
        }
        scroll.addView(body)
        shell.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        shell.addView(text("FLAME CLIENT  •  FIRE UI  •  ANDROID", 9f, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(9), 0, dp(2))
        })
        setContentView(shell)
    }

    private fun renderClickGui(body: LinearLayout) {
        val summary = card()
        val summaryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val summaryText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        summaryText.addView(text("MODULE CENTER", 15f, white, true))
        summaryText.addView(text("Chọn nhóm • tìm module • bật/tắt", 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
        summaryRow.addView(summaryText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val enabledCount = modules.count { preferences().getBoolean(prefKey(it), false) }
        val activeBadge = pill("$enabledCount SELECTED", Color.rgb(61, 30, 24), orange, 10f) {}
        activeCountBadge = activeBadge
        summaryRow.addView(activeBadge)
        summary.addView(summaryRow)
        body.addView(summary, margin(bottom = 10))

        val search = EditText(this).apply {
            setSingleLine(true)
            textSize = 13f
            setTextColor(white)
            setHintTextColor(muted)
            hint = "⌕  Tìm module..."
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(panelRaised, border, 12)
            setText(searchText)
            setSelection(text.length)
        }
        body.addView(search, margin(bottom = 10))

        val categoriesScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
        }
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categories.forEach { category ->
            val count = modules.count { it.category == category }
            val label = when (category) {
                "PVP" -> "⚔  PVP  $count"
                "SINH TỒN" -> "◇  SINH TỒN  $count"
                "HUD" -> "◉  HUD  $count"
                else -> "✦  VISUAL  $count"
            }
            categoryRow.addView(pill(label,
                if (selectedCategory == category) red else panel,
                if (selectedCategory == category) white else muted,
                10f, true) {
                selectedCategory = category
                render()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(39)).apply { marginEnd = dp(7) })
        }
        categoriesScroll.addView(categoryRow)
        body.addView(categoriesScroll, margin(bottom = 12))

        val categoryDescription = when (selectedCategory) {
            "PVP" -> "COMBAT MODULES"
            "SINH TỒN" -> "SURVIVAL MODULES"
            "HUD" -> "HUD & INFORMATION"
            else -> "VISUAL MODULES"
        }
        val sectionHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        sectionHead.addView(text(categoryDescription, 11f, orange, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sectionHead.addView(text("${modules.count { it.category == selectedCategory }} MODULES", 9f, muted, true))
        body.addView(sectionHead, margin(bottom = 7))

        moduleList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(moduleList)
        populateModuleList()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchText = s?.toString().orEmpty()
                populateModuleList()
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        val note = card()
        note.addView(text("⚠  MODULE STATUS", 11f, orange, true))
        note.addView(text("Module có pack sẽ mở luồng xuất/import khi bật. Khi Minecraft nhập xong, bro vẫn phải Activate pack ở Settings > Global Resources hoặc Resource Packs của thế giới. Module chưa có tích hợp sẽ không bật giả.", 11f, muted).apply { setPadding(0, dp(7), 0, 0) })
        body.addView(note, margin(top = 10))
    }

    private fun populateModuleList() {
        if (!::moduleList.isInitialized) return
        val enabledTotal = modules.count { preferences().getBoolean(prefKey(it), false) }
        activeCountBadge?.text = "$enabledTotal SELECTED"
        moduleList.removeAllViews()
        val query = searchText.trim().lowercase()
        val filtered = modules.filter {
            it.category == selectedCategory && (query.isEmpty() || it.name.lowercase().contains(query) || it.detail.lowercase().contains(query))
        }
        if (filtered.isEmpty()) {
            val empty = card()
            empty.addView(text("Không tìm thấy module", 14f, white, true))
            empty.addView(text("Thử tên khác hoặc chọn nhóm khác.", 11f, muted).apply { setPadding(0, dp(5), 0, 0) })
            moduleList.addView(empty)
            return
        }
        filtered.forEach { module ->
            val enabled = preferences().getBoolean(prefKey(module), false)
            val item = card()
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val icon = TextView(this).apply {
                text = module.icon
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(if (enabled) white else orange)
                background = rounded(if (enabled) Color.rgb(105, 42, 28) else Color.rgb(43, 28, 27), border, 10)
                layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(10) }
            }
            row.addView(icon)

            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            labels.addView(text(module.name, 13f, white, true))
            labels.addView(text(module.detail, 10f, muted).apply { setPadding(0, dp(4), 0, 0) })
            row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val settingsButton = pill("⚙", panelRaised, orange, 15f, true) {
                showModuleInfo(module)
            }
            row.addView(settingsButton, LinearLayout.LayoutParams(dp(34), dp(36)).apply { marginStart = dp(5) })

            val toggle = pill(if (enabled) "ON" else "OFF",
                if (enabled) greenOn else Color.rgb(54, 48, 50),
                if (enabled) Color.WHITE else muted, 11f, true) {}
            row.addView(toggle, LinearLayout.LayoutParams(dp(52), dp(36)).apply { marginStart = dp(6) })
            item.addView(row)
            item.setOnClickListener { showModuleInfo(module) }
            // Pack-backed modules launch the export/import handoff when turned on.
            toggle.setOnClickListener { toggleModule(module) }
            moduleList.addView(item, margin(bottom = 7))
        }
    }

    private fun showModuleInfo(module: Module) {
        val enabled = preferences().getBoolean(prefKey(module), false)
        val state = if (enabled) "ĐÃ CHỌN TRONG FLAME" else "OFF"
        val note = if (module.packFile != null) {
            "\n\nBật module sẽ xuất/mở ${module.packFile}. Sau khi Minecraft nhập file, cần Activate trong Settings > Global Resources hoặc cài đặt thế giới. Với .mcaddon, hãy kiểm tra và bật cả Behavior Pack lẫn Resource Pack nếu có. Tắt ở FLAME không thể tự gỡ pack đã bật trong Minecraft."
        } else {
            "\n\nChưa có tích hợp thật cho module này. FLAME sẽ giữ OFF thay vì giả vờ điều khiển Minecraft."
        }
        val builder = AlertDialog.Builder(this)
            .setTitle(module.name)
            .setMessage("Nhóm: ${module.category}\nTrạng thái FLAME: $state\n\n${module.detail}$note")
            .setNegativeButton("ĐÓNG", null)
        if (module.packFile != null) {
            builder.setPositiveButton(if (enabled) "MỞ PACK" else "NHẬP / ÁP DỤNG") { _, _ ->
                val edit = preferences().edit().putBoolean(prefKey(module), true)
                when (module.name) {
                    "Keystrokes" -> edit.putBoolean("module_CPS Counter", false)
                    "CPS Counter" -> edit.putBoolean("module_Keystrokes", false)
                }
                edit.apply()
                populateModuleList()
                exportPack(module.packFile, module.packMime, module.name)
            }
        }
        builder.show()
    }

    private fun toggleModule(module: Module) {
        val wasEnabled = preferences().getBoolean(prefKey(module), false)
        if (wasEnabled) {
            preferences().edit().putBoolean(prefKey(module), false).apply()
            populateModuleList()
            if (module.packFile != null) {
                Toast.makeText(this, "Đã tắt lựa chọn trong FLAME. Muốn tắt hiệu lực trong game, hãy Deactivate pack trong Minecraft.", Toast.LENGTH_LONG).show()
            }
            return
        }
        val pack = module.packFile
        if (pack == null) {
            AlertDialog.Builder(this)
                .setTitle(module.name)
                .setMessage("${module.detail}\n\nModule này chưa được tích hợp trực tiếp vào Minecraft, nên nút không thể bật thật trong game. Mình để OFF thay vì báo ON giả.")
                .setPositiveButton("XEM PACKS") { _, _ -> selectedSection = "PACKS"; render() }
                .setNegativeButton("ĐÓNG", null)
                .show()
            return
        }
        val edit = preferences().edit().putBoolean(prefKey(module), true)
        when (module.name) {
            "Keystrokes" -> edit.putBoolean("module_CPS Counter", false)
            "CPS Counter" -> edit.putBoolean("module_Keystrokes", false)
        }
        edit.apply()
        populateModuleList()
        exportPack(pack, module.packMime, module.name)
    }

    private fun renderPacks(body: LinearLayout) {
        body.addView(text("RESOURCE PACKS", 18f, white, true))
        body.addView(text("Xuất pack rồi mở bằng Minecraft. Sau khi nhập, bật pack trong Global Resources hoặc cài đặt thế giới.", 11f, muted).apply {
            setPadding(0, dp(5), 0, dp(12))
        })
        try {
            val catalog = JSONArray(assets.open("packs/catalog.json").bufferedReader().use { it.readText() })
            for (i in 0 until catalog.length()) {
                val item = catalog.getJSONObject(i)
                val file = item.getString("file")
                val p = card()
                p.addView(text(item.getString("title"), 14f, white, true))
                p.addView(text(item.getString("description"), 11f, muted).apply { setPadding(0, dp(5), 0, dp(10)) })
                p.addView(pill("XUẤT / MỞ PACK  ↗", red, white, 11f, true) {
                    exportPack(file, item.optString("mime", "application/x-mcpack"))
                })
                body.addView(p, margin(bottom = 9))
            }
        } catch (e: Exception) {
            val p = card()
            p.addView(text("Không đọc được danh sách pack", 13f, white, true))
            p.addView(text(e.message ?: "catalog.json không đọc được.", 11f, muted).apply { setPadding(0, dp(5), 0, 0) })
            body.addView(p)
        }
    }

    private fun renderSettings(body: LinearLayout) {
        body.addView(text("CLIENT SETTINGS", 18f, white, true))
        body.addView(text("Tùy chọn của ứng dụng FLAME CLIENT.", 11f, muted).apply {
            setPadding(0, dp(5), 0, dp(12))
        })
        val appSettings = card()
        appSettings.addView(text("APP & CLICKGUI", 11f, orange, true))
        appSettings.addView(text("• Click Hub có công tắc nhanh cho các module có pack.\n• Bật module sẽ tạo file .mcpack/.mcaddon và yêu cầu mở bằng Minecraft.\n• Minecraft cần nhập file và Activate pack trong Global Resources hoặc cài đặt thế giới.\n• Tắt trong FLAME không thể tự tắt pack đã kích hoạt bên trong Minecraft.", 12f, white).apply { setPadding(0, dp(8), 0, dp(10)) })
        appSettings.addView(pill("MỞ FLOATING GUI  ↗", red, white, 11f, true) { requestOverlay() })
        body.addView(appSettings, margin(bottom = 9))
        val limits = card()
        limits.addView(text("!  CHƯA TÍCH HỢP TRỰC TIẾP", 11f, orange, true))
        limits.addView(text("Freelook, minimap/tọa độ thời gian thực, Time Changer, Backups và Auto Sprint cần tích hợp runtime. FPS/Ping/CPS/Zoom/Motion Blur hiện dựa vào pack/add-on bên thứ ba, không phải hook trực tiếp của FLAME; độ tương thích API và hiệu quả thực tế chưa được kiểm thử. Ứng dụng Android độc lập không thể tự điều khiển thế giới Minecraft chỉ bằng công tắc.", 11f, muted).apply { setPadding(0, dp(8), 0, 0) })
        body.addView(limits, margin(bottom = 9))
        val target = card()
        target.addView(text("BUILD TARGET", 11f, orange, true))
        target.addView(text("Minecraft Bedrock / PE 1.26.52\nAndroid • Java 17 • Gradle 8.9\nTên gói: com.flameclient.android", 11f, muted).apply { setPadding(0, dp(7), 0, 0) })
        body.addView(target)
    }

    private fun mimeForPack(assetName: String): String = when {
        assetName.endsWith(".mcaddon", ignoreCase = true) -> "application/x-mcaddon"
        assetName.endsWith(".mcpack", ignoreCase = true) -> "application/x-mcpack"
        else -> "application/octet-stream"
    }

    private fun exportPack(assetName: String, mime: String, moduleName: String = "") {
        if (runCatching { assets.open("packs/$assetName").close() }.isFailure) {
            Toast.makeText(this, "Không tìm thấy pack trong APK: $assetName", Toast.LENGTH_LONG).show()
            if (moduleName.isNotBlank()) preferences().edit().putBoolean("module_$moduleName", false).apply()
            populateModuleList()
            return
        }
        pendingPack = assetName
        pendingModuleName = moduleName

        // Android 10+ can write directly to Downloads, avoiding the blank/ambiguous Save As picker.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val uri = savePackToDownloads(assetName)
                pendingModuleName = ""
                launchMinecraftImport(uri, assetName)
                Toast.makeText(this, "Đã lưu vào Downloads/FLAME CLIENT: $assetName", Toast.LENGTH_LONG).show()
                if (moduleName.isNotBlank()) {
                    Toast.makeText(this, "Sau khi nhập, Minecraft vẫn yêu cầu Activate pack. ON trong FLAME không thể tự bật pack trong thế giới.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                if (moduleName.isNotBlank()) preferences().edit().putBoolean("module_$moduleName", false).apply()
                pendingModuleName = ""
                populateModuleList()
                Toast.makeText(this, "Không lưu/mở được pack: ${e.message ?: "lỗi Android"}", Toast.LENGTH_LONG).show()
            }
            return
        }

        // Older Android: use the system document picker.
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, assetName)
        }
        try {
            startActivityForResult(intent, createPackFile)
        } catch (e: Exception) {
            if (pendingModuleName.isNotBlank()) preferences().edit().putBoolean("module_$pendingModuleName", false).apply()
            pendingModuleName = ""
            populateModuleList()
            Toast.makeText(this, "Không mở được trình lưu file: ${e.message ?: "lỗi Android"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun savePackToDownloads(assetName: String): Uri {
        val mime = mimeForPack(assetName)
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, assetName)
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime)
            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "${android.os.Environment.DIRECTORY_DOWNLOADS}/FLAME CLIENT")
            put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = contentResolver.insert(collection, values) ?: error("Android không tạo được file trong Downloads")
        try {
            val output = contentResolver.openOutputStream(uri, "w") ?: error("Không mở được file đích")
            assets.open("packs/$assetName").use { input -> output.use { input.copyTo(it) } }
            val ready = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
            }
            contentResolver.update(uri, ready, null, null)
            return uri
        } catch (e: Exception) {
            runCatching { contentResolver.delete(uri, null, null) }
            throw e
        }
    }

    private fun launchMinecraftImport(uri: Uri, assetName: String) {
        val possibleTypes = listOf(mimeForPack(assetName), "application/octet-stream", "application/zip", "application/*", "*/*")
        for (type in possibleTypes) {
            val targeted = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, type)
                setPackage("com.mojang.minecraftpe")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (targeted.resolveActivity(packageManager) != null) {
                val opened = runCatching { startActivity(targeted) }.isSuccess
                if (opened) return
            }
        }
        val general = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            if (general.resolveActivity(packageManager) != null) {
                startActivity(Intent.createChooser(general, "Mở $assetName bằng Minecraft"))
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Đã lưu pack")
                    .setMessage("Không tìm thấy trình nhập pack tự động. Mở Minecraft một lần để kiểm tra, hoặc vào ứng dụng Tệp > Downloads > FLAME CLIENT rồi chọn $assetName và mở bằng Minecraft.")
                    .setPositiveButton("ĐÃ HIỂU", null)
                    .show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Pack đã lưu ở Downloads/FLAME CLIENT. Mở file đó bằng Minecraft để nhập.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Using startActivityForResult for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createPackFile) return
        if (resultCode != RESULT_OK || data?.data == null) {
            if (pendingModuleName.isNotBlank()) {
                preferences().edit().putBoolean("module_$pendingModuleName", false).apply()
            }
            pendingModuleName = ""
            populateModuleList()
            return
        }
        val uri = data?.data ?: return
        try {
            assets.open("packs/$pendingPack").use { input ->
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "Không mở được file đích" }
                    input.copyTo(output)
                }
            }
            val module = pendingModuleName
            Toast.makeText(this, "Đã lưu $pendingPack. Đang yêu cầu Minecraft nhập pack… Nếu game không tự mở, hãy mở file trong Tệp.", Toast.LENGTH_LONG).show()
            launchMinecraftImport(uri, pendingPack)
            if (module.isNotBlank()) {
                Toast.makeText(this, "Sau khi nhập thành công, vào Settings > Global Resources hoặc Resource Packs của thế giới và Activate pack. ON trong FLAME chưa xác nhận game đã bật pack.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            if (pendingModuleName.isNotBlank()) preferences().edit().putBoolean("module_$pendingModuleName", false).apply()
            Toast.makeText(this, "Không thể xuất pack: ${e.message ?: "lỗi file"}", Toast.LENGTH_LONG).show()
        } finally {
            pendingModuleName = ""
            populateModuleList()
        }
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Cho phép FLAME CLIENT hiển thị trên ứng dụng khác để dùng ClickGUI nổi.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FlameOverlayService::class.java))
        Toast.makeText(this, "Đã mở nút FLAME nổi.", Toast.LENGTH_SHORT).show()
    }

    private fun preferences() = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
    private fun prefKey(module: Module) = "module_${module.name}"

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(11), dp(12), dp(11))
        background = rounded(panel, border, 13)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun pill(value: String, fill: Int, color: Int, size: Float, bold: Boolean = false, click: () -> Unit) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        background = rounded(fill, if (fill == red) red else border, 10)
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun margin(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
