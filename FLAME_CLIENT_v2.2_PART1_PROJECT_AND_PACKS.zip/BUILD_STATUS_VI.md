# Trạng thái FLAME CLIENT v2.2 — Click Hub + Pack Import Fix

## Đã sửa trong source ZIP
- Click Hub có 20 nút cuộn cho các pack kèm theo, không còn chỉ 8 nút cũ.
- Nút ON lưu lựa chọn dùng chung với MainActivity, xuất file pack và thử chuyển sang Minecraft; OFF chỉ bỏ chọn trong FLAME, cần Deactivate thủ công trong Minecraft nếu pack đã bật.
- Android 10+ ghi trực tiếp vào `Downloads/FLAME CLIENT` qua MediaStore để giảm thao tác Save As; Android cũ dùng document picker.
- Nút module dẫn đến các pack có liên quan; module không có tích hợp vẫn báo rõ thay vì bật ON giả.
- Catalog mở rộng thành 20 pack và có cảnh báo tương thích/subpack/dependency.
- Chuẩn hóa một số archive, bảo đảm `manifest.json` ở gốc các `.mcpack` đã sửa.
- Giữ nguyên build.gradle.kts, settings.gradle.kts, gradle.properties, app/build.gradle.kts, và workflow build-apk.yml; AndroidManifest chỉ thêm khai báo `<queries>` cho Minecraft để kiểm tra intent.

## Chưa thể khẳng định
- Môi trường này không có Gradle hoặc Android SDK nên chưa build/test được APK.
- Chưa thử trên Samsung Galaxy A36 5G hoặc Minecraft Bedrock/PE 1.26.52.
- Android companion app không có API công khai để tự Activate/Deactivate pack trong thế giới Minecraft đang chạy. App chỉ thực hiện bước export/import và hướng dẫn bật pack trong game.
- Một số pack có dependency Script API/extension/subpacks và có thể không chạy đúng trên phiên bản mục tiêu.
