# Trạng thái FLAME CLIENT 1.3 — bản chuẩn bị cho AndroidIDE

- Dự án Android/Kotlin với Gradle Kotlin DSL.
- Giữ nguyên các mã nguồn và pack có sẵn trong ZIP nguồn `v1.3_fixed(1)`.
- Thêm hướng dẫn build trên AndroidIDE tại `ANDROIDIDE_BUILD_VI.md`.
- Cấu hình hiện có: Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26; nên dùng JDK 17.
- ZIP nguồn không có Gradle Wrapper (`gradlew`/`gradle-wrapper.jar`). AndroidIDE có thể cần cấu hình Gradle riêng; workflow GitHub dùng Gradle 8.9 được giữ lại.
- Chưa build/kiểm thử APK trong môi trường hiện tại vì không có Gradle và Android SDK.
- Các pack được đóng gói trong assets; việc đóng gói không chứng minh pack tương thích Minecraft PE 1.26.52 hoặc tự áp dụng vào game.
- Overlay là giao diện nổi Android, không bảo đảm các tính năng cần truy cập nội bộ Minecraft (ví dụ Freelook/FPS/Ping trong game).
