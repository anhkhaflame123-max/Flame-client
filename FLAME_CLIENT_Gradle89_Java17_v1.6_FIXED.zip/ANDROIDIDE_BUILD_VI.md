# FLAME CLIENT — build APK bằng điện thoại (dễ nhất)

## Cấu hình đã chuẩn bị
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- Gradle build trên GitHub Actions: 8.9
- Java trên GitHub Actions: 17
- Java/Kotlin target của ứng dụng: 17
- Giữ nguyên mã nguồn Kotlin và các pack trong `app/src/main/assets/packs/`.

Lưu ý: Gradle 8.9 là phiên bản được cấu hình tương thích với Android Gradle Plugin 8.7.3 của dự án; đây không phải tuyên bố rằng 8.9 là bản Gradle mới nhất tuyệt đối. Máy AndroidIDE của bạn đang báo Java 8 và Gradle 6.1.1. ZIP này đã đặt cấu hình mã nguồn Java/Kotlin ở mức 17, nhưng **không thể tự nâng Java của AndroidIDE chỉ bằng cách sửa ZIP**. Hãy build bằng GitHub Actions (nơi workflow tự cài Java 17 và Gradle 8.9), hoặc cài/cấu hình JDK 17 riêng trong AndroidIDE nếu phiên bản AndroidIDE hỗ trợ. ZIP này là mã nguồn, không phải APK đã biên dịch; chưa thể khẳng định APK build thành công cho tới khi workflow chạy xanh.

## Cách build APK trên điện thoại qua GitHub
1. Giải nén ZIP này. Mở thư mục gốc, nơi có `settings.gradle.kts`, `build.gradle.kts` và thư mục `.github`.
2. Vào repository GitHub của bạn, ví dụ `Flame-client`.
3. Tải toàn bộ nội dung bên trong thư mục gốc này lên repository, giữ nguyên cấu trúc thư mục. Không chỉ tải mỗi thư mục `app`.
4. Đảm bảo file `.github/workflows/build-apk.yml` có trong repository. File này tự dùng Java 17 và Gradle 8.9 trên máy build của GitHub.
5. Mở tab **Actions** trên GitHub. Chọn **Build FLAME CLIENT APK** → **Run workflow** → **Run workflow**.
6. Mở lượt chạy vừa tạo. Chờ job `build` hoàn tất thành công.
7. Ở cuối trang lượt chạy, trong **Artifacts**, tải `FLAME_CLIENT-debug-apk`. Giải nén file tải về để lấy `app-debug.apk`.
8. Mở APK trên điện thoại để cài đặt. Nếu Android chặn, chỉ cho phép cài ứng dụng từ nguồn này nếu bạn tin tưởng file do chính repository của mình tạo ra.

## Nếu không thấy Artifacts
- Nếu lượt chạy là workflow tên khác như `Add basic CI workflow`, đó không phải workflow build APK.
- Mở repository → thư mục `.github/workflows/` và xác nhận có `build-apk.yml`.
- Chạy workflow **Build FLAME CLIENT APK**. Chỉ khi build hoàn tất và bước upload artifact thành công thì Artifacts mới xuất hiện.

## Giới hạn
- Đây là mã nguồn, không kèm APK đã build.
- Build thành công không có nghĩa mọi tính năng overlay đều đã được kiểm thử trong Minecraft Bedrock 1.26.52.
- Các file `.mcpack`/`.mcaddon` được giữ trong dự án; việc đóng gói không tự cài hoặc kích hoạt chúng trong Minecraft.
