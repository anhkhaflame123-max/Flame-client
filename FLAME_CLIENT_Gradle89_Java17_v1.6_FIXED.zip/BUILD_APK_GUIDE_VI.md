# Cách build APK FLAME CLIENT 1.3

ZIP này là **mã nguồn Android**, không phải APK đã biên dịch.

## Cách A — AndroidIDE trên điện thoại
Làm theo `ANDROIDIDE_BUILD_VI.md`. Mở thư mục gốc có `settings.gradle.kts`, đồng bộ Gradle, sau đó chạy `:app:assembleDebug`. APK đầu ra dự kiến: `app/build/outputs/apk/debug/app-debug.apk`.

## Cách B — GitHub Actions
1. Tải toàn bộ nội dung ZIP lên repository, giữ nguyên thư mục `.github/workflows/`.
2. Mở **Actions** → **Build FLAME CLIENT APK** → **Run workflow**.
3. Khi job thành công, tải artifact `FLAME_CLIENT-debug-apk` và giải nén để lấy `app-debug.apk`.

## Lưu ý
- Không tải riêng mỗi file workflow: cần cả thư mục `app/`, các file Gradle và toàn bộ tài nguyên.
- Debug APK chưa phải bản phát hành đã ký.
- Chưa có xác nhận build thành công hoặc kiểm thử trên thiết bị thật trong lần chuẩn bị ZIP này.
