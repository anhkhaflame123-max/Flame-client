package com.flameclient.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 13)
    private val card = Color.rgb(25, 20, 22)
    private val red = Color.rgb(255, 55, 42)
    private val orange = Color.rgb(255, 126, 38)
    private val white = Color.rgb(247, 242, 240)
    private val muted = Color.rgb(180, 166, 165)
    private val createPackFile = 7201
    private var pendingPack = ""
    private var pendingMime = "application/x-mcpack"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = 0
        render()
    }

    private fun render() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(24)); setBackgroundColor(bg) }
        page.addView(label("🔥 FLAME CLIENT", 29f, orange, true))
        page.addView(label("ANDROID EDITION • MINECRAFT PE 1.26.52 • BUILD 1.3", 11f, muted).apply { setPadding(0, dp(3), 0, dp(18)) })
        val hero = panel()
        hero.addView(label("BURN BRIGHT. PLAY SMART.", 19f, white, true))
        hero.addView(label("Đen / Đỏ / Cam • Pack Manager", 13f, orange).apply { setPadding(0, dp(5), 0, dp(12)) })
        hero.addView(action("BẬT CLICKGUI NỔI", red) { requestOverlay() })
        page.addView(hero, margin(bottom = 14))

        page.addView(section("RESOURCE PACK MANAGER"))
        page.addView(label("Chọn Xuất / Mở để lưu pack rồi thử mở bằng Minecraft. Các pack được giữ riêng, không tự gộp để tránh xung đột. Sau khi nhập, kích hoạt trong cài đặt thế giới hoặc Global Resources tùy pack.", 12f, muted).apply { setPadding(0, 0, 0, dp(10)) })
        val catalog = JSONArray(assets.open("packs/catalog.json").bufferedReader().use { it.readText() })
        for (i in 0 until catalog.length()) {
            val item = catalog.getJSONObject(i)
            val file = item.getString("file")
            val p = panel()
            p.addView(label(item.getString("title"), 15f, orange, true))
            p.addView(label(item.getString("description"), 12f, muted).apply { setPadding(0, dp(5), 0, dp(10)) })
            p.addView(action("XUẤT / MỞ PACK", red) { exportPack(file, item.getString("mime")) })
            page.addView(p, margin(bottom = 9))
        }

        page.addView(section("MODULES / GIỚI HẠN HIỆN TẠI"))
        val notes = panel()
        notes.addView(label("""• ClickGUI nổi: giao diện Android, không điều khiển bộ nhớ Minecraft.
• ChunkFinder, kính, Small Items, Low Fire: resource pack; phải bật trong game.
• Keystrokes/CPS và PvP Pack có thể trùng HUD; chỉ bật từng pack để kiểm tra.
• FPS/Ping/CPS, Freelook, Zoom, Motion Blur, Lua, Minimap và các hệ thống tài khoản chưa được xác nhận hoạt động trong game chỉ từ ứng dụng này.""", 12f, muted))
        page.addView(notes)
        page.addView(label("FLAME CLIENT • PERSONAL PACK MANAGER • NOT TESTED IN-GAME", 10f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(page) })
    }

    private fun exportPack(assetName: String, mime: String) {
        pendingPack = assetName
        pendingMime = mime
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, assetName)
        }
        startActivityForResult(intent, createPackFile)
    }

    @Deprecated("Using startActivityForResult for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createPackFile || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            assets.open("packs/$pendingPack").use { input ->
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "Không mở được file đích" }
                    input.copyTo(output)
                }
            }
            Toast.makeText(this, "Đã lưu $pendingPack. Đang mở bằng Minecraft…", Toast.LENGTH_LONG).show()
            val open = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, pendingMime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            try { startActivity(open) } catch (_: Exception) {
                Toast.makeText(this, "Nếu Minecraft chưa tự mở, hãy mở file vừa lưu trong ứng dụng Tệp.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Không thể xuất pack: ${e.message ?: "lỗi file"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Cho phép FLAME CLIENT hiển thị trên ứng dụng khác để dùng ClickGUI nổi.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FlameOverlayService::class.java))
        Toast.makeText(this, "Đã mở nút FLAME nổi.", Toast.LENGTH_SHORT).show()
    }
    private fun panel() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = android.graphics.drawable.GradientDrawable().apply { setColor(card); cornerRadius = dp(14).toFloat(); setStroke(dp(1), Color.rgb(86, 35, 27)) } }
    private fun section(s: String) = label(s, 12f, red, true).apply { setPadding(dp(2), dp(7), 0, dp(9)) }
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    private fun action(title: String, color: Int, click: () -> Unit) = Button(this).apply { text = title; textSize = 12f; setTextColor(Color.WHITE); background = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(9).toFloat() }; setOnClickListener { click() } }
    private fun margin(bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
