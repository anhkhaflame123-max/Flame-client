# FLAME CLIENT 1.2 — Trạng thái trung thực

- Mục tiêu: Minecraft PE/Bedrock 1.26.52 trên Android.
- Có: trang chủ Android phong cách đen/đỏ/cam, nút yêu cầu quyền overlay, menu nổi Android cơ bản, pack Bedrock ChunkFinder v1.2.0 nhúng trong assets và chức năng xuất pack.
- ChunkFinder là resource pack riêng của Minecraft. Sau khi xuất/import, người dùng phải kích hoạt nó trong Resource Packs của thế giới.
- Chưa có: điều khiển trực tiếp nội bộ Minecraft, bộ đếm FPS/CPS/Totem lấy dữ liệu game thật, hoặc các module PvP được chứng minh hoạt động. Các mục HUD hiện là phần giao diện/placeholder.
- Chưa biên dịch hoặc kiểm thử trên thiết bị trong môi trường tạo file này. Không phải APK.
- ChunkFinder GPL-3.0: giữ LICENSE/README và cung cấp source tương ứng khi phân phối.
