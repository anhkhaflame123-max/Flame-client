package com.flameclient.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 13)
    private val card = Color.rgb(25, 20, 22)
    private val red = Color.rgb(255, 55, 42)
    private val orange = Color.rgb(255, 126, 38)
    private val white = Color.rgb(247, 242, 240)
    private val muted = Color.rgb(180, 166, 165)
    private val createPackFile = 7201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = 0
        render()
    }

    private fun render() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(bg)
        }
        page.addView(TextView(this).apply {
            text = "🔥 FLAME CLIENT"
            textSize = 29f
            setTextColor(orange)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        })
        page.addView(label("ANDROID EDITION  •  MINECRAFT PE 1.26.52  •  BUILD 1.2", 11f, muted).apply {
            setPadding(0, dp(3), 0, dp(18))
        })

        val hero = panel()
        hero.addView(label("BURN BRIGHT. PLAY SMART.", 19f, white, true))
        hero.addView(label("Trang chủ FLAME • Đen / Đỏ / Cam", 13f, orange).apply { setPadding(0, dp(5), 0, dp(12)) })
        hero.addView(action("BẬT CLICKGUI NỔI", red) { requestOverlay() })
        page.addView(hero, margin(bottom = 14))

        page.addView(section("CLIENT MODULES"))
        val modules = listOf(
            "⚔  PvP HUD" to "Giao diện HUD mẫu; không đọc dữ liệu nội bộ game.",
            "🚀  FPS SETUP" to "Mở hướng dẫn tối ưu cài đặt Minecraft.",
            "🎯  CROSSHAIR" to "Tùy chỉnh hiển thị trong overlay; chưa đổi tâm ngắm game.",
            "🧭  CHUNK BORDERS" to "Đóng gói sẵn Bedrock ChunkFinder v1.2.0 ở bên dưới."
        )
        modules.forEach { (name, desc) ->
            val p = panel()
            p.addView(label(name, 15f, white, true))
            p.addView(label(desc, 12f, muted).apply { setPadding(0, dp(5), 0, 0) })
            page.addView(p, margin(bottom = 9))
        }

        page.addView(section("RESOURCE PACKS"))
        val pack = panel()
        pack.addView(label("🧱  BEDROCK CHUNKFINDER", 16f, orange, true))
        pack.addView(label("v1.2.0 • nhắm mục tiêu Minecraft PE 1.26.52 • cần nhập và bật trong Minecraft", 12f, muted).apply {
            setPadding(0, dp(6), 0, dp(12))
        })
        pack.addView(action("XUẤT / MỞ PACK CHUNKFINDER", orange) { exportChunkFinder() })
        pack.addView(label("Sau khi nhập: chỉnh sửa thế giới → Resource Packs → My Packs → Activate. Pack có công tắc riêng cho chunk borders, slime chunks và bottom grid; cần kiểm tra thực tế trên 1.26.52.", 12f, muted).apply {
            setPadding(0, dp(10), 0, 0)
        })
        page.addView(pack, margin(bottom = 14))

        page.addView(section("LƯU Ý TƯƠNG THÍCH"))
        val note = panel()
        note.addView(label("ChunkFinder là resource pack của Minecraft, không phải module Android tự vẽ chunk. ClickGUI chỉ là lớp phủ Android; pack cần được nhập và kích hoạt trong thế giới. Mục tiêu kiểm tra: Minecraft PE 1.26.52. Pack khai báo min_engine_version 1.26.0, nhưng chưa được kiểm thử thực tế trên 1.26.52. Ứng dụng không tự sửa game; pack phải được nhập và kích hoạt trong cài đặt thế giới.", 12f, muted))
        page.addView(note)
        page.addView(label("FLAME CLIENT • COMMUNITY STARTER • GPL PACK ATTRIBUTION INCLUDED", 10f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); addView(page) }
        setContentView(scroll)
    }

    private fun exportChunkFinder() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/x-mcpack"
            putExtra(Intent.EXTRA_TITLE, "BedrockChunkFinderRPMCBEv1.2.0.mcpack")
        }
        startActivityForResult(intent, createPackFile)
    }

    @Deprecated("Using startActivityForResult for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createPackFile || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            assets.open("packs/BedrockChunkFinderRPMCBEv1.2.0.mcpack").use { input ->
                contentResolver.openOutputStream(uri, "w").use { output ->
                    requireNotNull(output) { "Không mở được file đích" }
                    input.copyTo(output)
                }
            }
            Toast.makeText(this, "Đã lưu pack. Đang thử mở bằng Minecraft…", Toast.LENGTH_LONG).show()
            val open = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/x-mcpack")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(open) }
            catch (_: Exception) {
                Toast.makeText(this, "Nếu Minecraft chưa tự mở: vào Tệp của bạn, mở file .mcpack vừa lưu bằng Minecraft.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Không thể xuất pack: ${e.message ?: "lỗi file"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Cho phép FLAME CLIENT hiển thị trên ứng dụng khác để dùng ClickGUI nổi.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FlameOverlayService::class.java))
        Toast.makeText(this, "Đã mở nút FLAME nổi. Chạm nút để bung ClickGUI.", Toast.LENGTH_SHORT).show()
    }

    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(card); cornerRadius = dp(14).toFloat()
            setStroke(dp(1), Color.rgb(86, 35, 27))
        }
    }
    private fun section(s: String) = label(s, 12f, red, true).apply { setPadding(dp(2), dp(7), 0, dp(9)) }
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun action(title: String, color: Int, click: () -> Unit) = Button(this).apply {
        text = title; textSize = 12f; setTextColor(Color.WHITE)
        background = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(9).toFloat() }
        setOnClickListener { click() }
    }
    private fun margin(bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
