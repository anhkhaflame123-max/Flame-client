plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.flameclient.android"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.flameclient.android"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}
