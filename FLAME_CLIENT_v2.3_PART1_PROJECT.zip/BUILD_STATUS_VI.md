# FLAME CLIENT v2.3 — trạng thái source

## Đã chỉnh trong source
- `versionName = "2.3"`, `versionCode = 9`.
- Biểu tượng adaptive icon FLAME đỏ–cam–đen được cấu hình trong manifest.
- ClickGUI hiển thị rõ v2.3.
- Công tắc module dùng `IMPORT` / `SELECT` để phân biệt thao tác nhập pack với lựa chọn trong ứng dụng.
- PACKS có tìm kiếm theo tên, mô tả hoặc tên file và bộ đếm kết quả.
- Settings có hành động mở Minecraft và đặt lại lựa chọn module.
- Xuất lại pack cùng tên trên Android 10+ thử xóa file cũ trong thư mục Downloads trước khi ghi bản mới.
- Workflow nhận diện file source v2.3, xóa project cũ trước khi bung source mới và từ chối build bản cũ.
- `scripts/verify_source.py` xác minh versionCode/versionName, icon, 20 entry catalog, file assets và archive trước khi compile.

## Đã kiểm tra
- Script QA: PASSED, 20/20 mục catalog được kiểm tra; mọi pack file được catalog trỏ tới đều tồn tại.
- ZIP integrity: toàn bộ `.mcpack`/`.mcaddon` trong catalog đọc được và không báo member bị hỏng.
- XML parser: AndroidManifest, launcher foreground, colors và adaptive icon đều parse thành công.

## Chưa thể tuyên bố
- Chưa chạy Gradle assemble trong môi trường tạo ZIP do không có Android SDK/Gradle cài sẵn.
- Chưa cài thử trên Samsung Galaxy A36 5G và chưa kiểm thử trực tiếp với Minecraft PE 1.26.52.
- Chưa có inject/hook Minecraft: Android companion app chỉ xuất/import pack, không thể tự Activate/Deactivate pack trong thế giới đang chạy.
- Module Freelancer/Minimap/Time Changer/Backups/Auto Sprint chưa có tích hợp runtime thật. Add-on bên thứ ba có thể không tương thích API hoặc xung đột nhau.
