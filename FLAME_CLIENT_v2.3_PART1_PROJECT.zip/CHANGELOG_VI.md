# FLAME CLIENT — Changelog

## v2.3 (versionCode 9)
- Đổi app version để APK mới không còn mang phiên bản 2.2 cũ.
- Thêm adaptive launcher icon FLAME.
- Thêm tìm kiếm trong Pack Library.
- Thêm tên file pack và bộ đếm kết quả.
- Đổi nhãn trạng thái từ ON/OFF gây hiểu nhầm sang IMPORT/SELECT.
- Thêm nút mở Minecraft và đặt lại lựa chọn trong Settings.
- Giảm nguy cơ có nhiều file export trùng tên trong Downloads.
- Thêm pre-build QA và workflow chặn source cũ.

## Giới hạn không đổi
FLAME là companion app Android. Tính năng cần hook/inject game hoặc API nội bộ không được tuyên bố hoạt động khi chưa có triển khai và kiểm thử thực tế.
