# Hướng dẫn build FLAME CLIENT v2.3 APK

File ZIP nguồn không phải APK. APK được tạo bằng GitHub Actions.

## Cách build bằng GitHub trên điện thoại

1. Khuyến nghị trên GitHub mobile: upload cả `FLAME_CLIENT_v2.3_PART1_PROJECT.zip` và `FLAME_CLIENT_v2.3_PART2_LARGE_PACKS.zip` vào thư mục gốc repository. Có thể dùng file đầy đủ `FLAME_CLIENT_v2.3_FLAME_REWORK.zip` thay thế nếu upload được.
2. Mở `.github/workflows/build-apk.yml` → **Edit**; thay toàn bộ nội dung bằng file `FLAME_CLIENT_v2.3_build-apk.yml`; bấm **Commit changes**. Đảm bảo source ZIP đã được thêm trước khi commit workflow.
3. Mở tab **Actions** → **Build FLAME CLIENT v2.3 APK** → **Run workflow**.
4. Chờ tới khi tất cả bước và bước upload artifact màu xanh.
5. Mở **Artifacts**, tải `FLAME_CLIENT-v2.3-debug-apk`, rồi lấy `FLAME_CLIENT-v2.3-debug.apk`.
6. Sau khi cài, mở **FLAME CLIENT > SETTINGS** và kiểm tra có dòng `FLAME CLIENT v2.3 • versionCode 9`.

Workflow giữ nguyên bộ SDK: Java 17, Gradle 8.9, Android SDK platform 35, Build Tools 35.0.0. Nó kiểm tra source v2.3 trước khi build và từ chối bản cũ.

## Nếu APK vẫn hiện giao diện cũ

- Đảm bảo tải artifact mới nhất từ đúng lượt chạy sau khi đưa ZIP v2.3 lên repository.
- Kiểm tra tên artifact là `FLAME_CLIENT-v2.3-debug-apk`, không tải artifact cũ đã có sẵn.
- Trong ứng dụng mở **SETTINGS** để kiểm tra version 2.3 / code 9.
- Nếu Android báo chữ ký không khớp và từ chối cài bản cập nhật, gỡ bản FLAME cũ rồi cài APK mới. Gỡ ứng dụng sẽ xóa tùy chọn đã lưu trong FLAME.

## Giới hạn

FLAME là ứng dụng đồng hành Android: nó xuất/mở pack để Minecraft nhập. Nó không thể tự bật/tắt resource/behavior packs trong một thế giới đang chạy. Các module cần hook/inject game không được tuyên bố hoạt động khi chưa triển khai và kiểm thử runtime.
