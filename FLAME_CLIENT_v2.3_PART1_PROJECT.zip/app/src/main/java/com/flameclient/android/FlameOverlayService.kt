package com.flameclient.android

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** Floating Click Hub. Pack toggles open the real pack-import handoff; they cannot
 * directly activate/deactivate packs inside a running Bedrock world. */
class FlameOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var menuContent: LinearLayout? = null
    private var menuScroll: ScrollView? = null
    private var expanded = false
    private lateinit var params: WindowManager.LayoutParams

    private val dark = Color.rgb(19, 13, 15)
    private val red = Color.rgb(255, 54, 40)
    private val orange = Color.rgb(255, 125, 35)
    private val white = Color.rgb(247, 243, 242)
    private val muted = Color.rgb(190, 176, 178)

    private data class QuickPack(val name: String, val moduleName: String, val file: String)
    private val quickPacks = listOf(
        QuickPack("Zoom • Just Zoom", "Zoom", "zoom.mcaddon"),
        QuickPack("Small Hand", "Small Hand", "better_hands.mcpack"),
        QuickPack("FPS Booster", "FPS Booster", "fps_booster.mcpack"),
        QuickPack("FPS Counter", "FPS Counter", "fps_counter.mcpack"),
        QuickPack("Ping Check • script", "Ping Counter", "ping_check.mcpack"),
        QuickPack("CPS Counter", "CPS Counter", "osk_cps.mcpack"),
        QuickPack("Motion Blur", "Motion Blur", "motion_blur.mcpack"),
        QuickPack("Crosshair Customizer", "Crosshair Customizer", "custom_crosshairs.mcpack"),
        QuickPack("Totem Counter • Ext. UI", "Totem Counter", "totem_counter.mcpack"),
        QuickPack("Utility HUD", "Utility HUD", "utility_hud.mcpack"),
        QuickPack("Potion Status", "Potion Status", "potion_hud.mcpack"),
        QuickPack("Chunk Finder", "Chunk Finder", "chunkfinder.mcpack"),
        QuickPack("Keystrokes + CPS", "Keystrokes", "keystrokes_cps.mcpack"),
        QuickPack("Direction HUD", "Direction HUD", "direction_hud.mcaddon"),
        QuickPack("Hotbar Button", "Hotbar Button", "slot_hotbar_button.mcpack"),
        QuickPack("Crosshair Style • Gavti", "Crosshair Style", "gavti_pvp.mcaddon"),
        QuickPack("OS CLIENT Pack", "OS CLIENT Pack", "os_client.mcpack"),
        QuickPack("Low Fire", "Low Fire", "low_fire.mcpack"),
        QuickPack("Clear Glass", "Clear Glass", "clear_glass.mcpack"),
        QuickPack("Small Items", "Small Items", "small_items.mcpack")
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (root == null) showBubble()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun showBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(75)
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = rounded(dark, Color.rgb(111, 37, 25))
        }
        val badge = TextView(this).apply {
            text = if (expanded) "🔥 FLAME  ▴" else "🔥 FLAME  ▾"
            tag = "flame_badge"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(red, red)
            setOnClickListener {
                expanded = !expanded
                text = if (expanded) "🔥 FLAME  ▴" else "🔥 FLAME  ▾"
                refreshMenu(box)
            }
            setOnTouchListener(DragTouchListener())
        }
        box.addView(badge)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(4), dp(3), dp(2))
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            clipToPadding = false
            visibility = View.GONE
            addView(content, ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT))
        }
        val maxHeight = minOf((resources.displayMetrics.heightPixels * 0.60f).toInt(), dp(500))
        box.addView(scroll, LinearLayout.LayoutParams(dp(282), maxHeight.coerceAtLeast(dp(240))))
        menuContent = content
        menuScroll = scroll
        root = box

        try {
            wm.addView(box, params)
            refreshMenu(box)
        } catch (_: Exception) {
            root = null
            menuContent = null
            menuScroll = null
            toast("Không thể hiện nút nổi. Hãy bật quyền hiển thị trên ứng dụng khác cho FLAME CLIENT.")
            stopSelf()
        }
    }

    private fun refreshMenu(box: LinearLayout) {
        val menu = menuContent ?: return
        menu.removeAllViews()
        menuScroll?.visibility = if (expanded) View.VISIBLE else View.GONE
        if (!expanded) return

        menu.addView(item("OPEN FLAME CLICKGUI ↗", orange, true) { openMainActivity("MODULES") })
        menu.addView(item("ALL PACKS / EXPORT ↗", white) { openMainActivity("PACKS") })
        menu.addView(item("SETTINGS / LIMITS ↗", white) { openMainActivity("SETTINGS") })
        menu.addView(item("QUICK PACKS • FLAME v2.3", orange, true) {})
        menu.addView(item("ON = export/import. Sau đó phải Activate trong Minecraft; OFF không tự gỡ pack trong game.", muted) {
            openMainActivity("SETTINGS")
        })
        quickPacks.forEach { pack -> menu.addView(quickPackRow(pack)) }
        menu.addView(item("Freelook / Time Changer / Backups chưa có tích hợp thật.", muted) {
            toast("Module này đang OFF vì chưa có tích hợp tương thích Minecraft.")
        })
        menu.addView(item("THU GỌN MENU", white, true) {
            expanded = false
            root?.findViewWithTag<TextView>("flame_badge")?.text = "🔥 FLAME  ▾"
            refreshMenu(box)
        })
        menu.addView(item("ĐÓNG NÚT NỔI", red, true) { stopSelf() })
    }

    private fun quickPackRow(pack: QuickPack): View {
        val prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        val enabled = prefs.getBoolean("module_${pack.moduleName}", false)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(2), dp(2), dp(2))
        }
        val title = TextView(this).apply {
            text = pack.name
            textSize = 11f
            setTextColor(white)
            setPadding(dp(4), dp(7), dp(3), dp(7))
        }
        row.addView(title, LinearLayout.LayoutParams(0, WindowManager.LayoutParams.WRAP_CONTENT, 1f))
        val state = TextView(this).apply {
            text = if (enabled) "SELECT" else "IMPORT"
            textSize = 8.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(if (enabled) Color.rgb(164, 53, 29) else Color.rgb(65, 42, 36), orange)
            isClickable = true
            isFocusable = true
            setOnClickListener { toggleQuickPack(pack) }
        }
        row.addView(state, LinearLayout.LayoutParams(dp(58), dp(34)).apply { marginStart = dp(4) })
        return row
    }

    private fun toggleQuickPack(pack: QuickPack) {
        val prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        val key = "module_${pack.moduleName}"
        val enabled = prefs.getBoolean(key, false)
        if (enabled) {
            prefs.edit().putBoolean(key, false).apply()
            toast("Đã OFF ${pack.moduleName} trong FLAME. Nếu pack đã được Activate, hãy Deactivate nó trong Minecraft.")
            root?.let { refreshMenu(it) }
            return
        }
        val edit = prefs.edit().putBoolean(key, true)
        if (pack.moduleName == "Keystrokes") edit.putBoolean("module_CPS Counter", false)
        if (pack.moduleName == "CPS Counter") edit.putBoolean("module_Keystrokes", false)
        edit.apply()
        toast("Đang xuất ${pack.file} để nhập bằng Minecraft. Đây là bước nhập pack, chưa phải bật trực tiếp trong thế giới.")
        openMainActivity("PACKS", pack.file, pack.moduleName)
        root?.let { refreshMenu(it) }
    }

    private fun openMainActivity(section: String = "MODULES", packFile: String? = null, moduleName: String = "") {
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra(MainActivity.EXTRA_OPEN_SECTION, section)
                if (!packFile.isNullOrBlank()) putExtra(MainActivity.EXTRA_EXPORT_PACK, packFile)
                if (moduleName.isNotBlank()) putExtra(MainActivity.EXTRA_MODULE_NAME, moduleName)
            }
            startActivity(intent)
        } catch (e: Exception) {
            toast("Không mở được FLAME CLIENT: ${e.message ?: "kiểm tra quyền mở ứng dụng"}")
        }
    }

    private fun item(label: String, color: Int, bold: Boolean = false, click: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 11f
        setTextColor(color)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        isClickable = true
        isFocusable = false
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setOnClickListener { click() }
    }

    private fun rounded(fill: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(11).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        root?.let { view -> runCatching { wm.removeView(view) } }
        root = null
        menuContent = null
        menuScroll = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var dragged = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    dragged = false
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) + abs(dy) > dp(6)) dragged = true
                    if (dragged) {
                        params.x = (startX + dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(0)
                        runCatching { root?.let { wm.updateViewLayout(it, params) } }
                        return true
                    }
                    return false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return dragged
            }
            return false
        }
    }
}
