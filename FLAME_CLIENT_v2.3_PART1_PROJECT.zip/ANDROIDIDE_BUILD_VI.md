# FLAME CLIENT v2.3 — build APK bằng điện thoại

## Cấu hình đã chuẩn bị
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- Gradle build trên GitHub Actions: 8.9
- Java trên GitHub Actions: 17
- Java/Kotlin target của ứng dụng: 17
- Giữ nguyên mã nguồn Kotlin và các pack trong `app/src/main/assets/packs/`.

Lưu ý: Gradle 8.9 là phiên bản được cấu hình tương thích với Android Gradle Plugin 8.7.3 của dự án; đây không phải tuyên bố rằng 8.9 là bản Gradle mới nhất tuyệt đối. Máy AndroidIDE của bạn đang báo Java 8 và Gradle 6.1.1. ZIP này đã đặt cấu hình mã nguồn Java/Kotlin ở mức 17, nhưng **không thể tự nâng Java của AndroidIDE chỉ bằng cách sửa ZIP**. Hãy build bằng GitHub Actions (nơi workflow tự cài Java 17 và Gradle 8.9), hoặc cài/cấu hình JDK 17 riêng trong AndroidIDE nếu phiên bản AndroidIDE hỗ trợ. ZIP này là mã nguồn, không phải APK đã biên dịch; chưa thể khẳng định APK build thành công cho tới khi workflow chạy xanh.

## Cách build APK trên điện thoại qua GitHub
1. Tải lên repository cả `FLAME_CLIENT_v2.3_PART1_PROJECT.zip` và `FLAME_CLIENT_v2.3_PART2_LARGE_PACKS.zip`, hoặc dùng file đầy đủ `FLAME_CLIENT_v2.3_FLAME_REWORK.zip` nếu upload được.
2. Mở `.github/workflows/build-apk.yml` và thay toàn bộ nội dung bằng `FLAME_CLIENT_v2.3_build-apk.yml`; Commit Changes sau khi ZIP nguồn đã có trong repository.
3. Mở **Actions** → **Build FLAME CLIENT v2.3 APK** → **Run workflow**.
4. Đợi tới khi build và upload artifact hoàn tất màu xanh.
5. Trong **Artifacts**, tải `FLAME_CLIENT-v2.3-debug-apk`, rồi cài file `FLAME_CLIENT-v2.3-debug.apk`.
6. Mở FLAME > SETTINGS để kiểm tra version 2.3 / code 9.

## Nếu không thấy Artifacts
- Nếu lượt chạy là workflow tên khác như `Add basic CI workflow`, đó không phải workflow build APK.
- Mở repository → thư mục `.github/workflows/` và xác nhận có `build-apk.yml`.
- Chạy workflow **Build FLAME CLIENT v2.3 APK**. Chỉ khi build hoàn tất và bước upload artifact thành công thì Artifacts mới xuất hiện.

## Giới hạn
- Đây là mã nguồn, không kèm APK đã build.
- Build thành công không có nghĩa mọi tính năng overlay đều đã được kiểm thử trong Minecraft Bedrock 1.26.52.
- Các file `.mcpack`/`.mcaddon` được giữ trong dự án; việc đóng gói không tự cài hoặc kích hoạt chúng trong Minecraft.
