# FLAME CLIENT v2.3 — build APK bằng điện thoại

## Cấu hình
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- Gradle trên GitHub Actions: 8.9
- Java trên GitHub Actions: 17
- Android SDK: platform 35, Build Tools 35.0.0
- App version: 2.3, `versionCode 9`
- Pack assets: `app/src/main/assets/packs/`

## Các bước trên GitHub mobile
1. Trên GitHub mobile, upload cả `FLAME_CLIENT_v2.3_PART1_PROJECT.zip` và `FLAME_CLIENT_v2.3_PART2_LARGE_PACKS.zip` vào thư mục gốc repository; hoặc upload file đầy đủ `FLAME_CLIENT_v2.3_FLAME_REWORK.zip` nếu được.
2. Mở `.github/workflows/build-apk.yml`, dán toàn bộ nội dung từ `FLAME_CLIENT_v2.3_build-apk.yml`, rồi Commit Changes. Thêm ZIP trước khi commit workflow.
3. Vào **Actions** → **Build FLAME CLIENT v2.3 APK** → **Run workflow**.
4. Chờ job mới nhất xanh hoàn toàn.
5. Trong **Artifacts**, tải `FLAME_CLIENT-v2.3-debug-apk`, sau đó cài file `FLAME_CLIENT-v2.3-debug.apk`.
6. Mở FLAME > **SETTINGS**; version hiển thị phải là 2.3 / code 9.

## Vì sao bản cũ có thể không thay thế được?
Nếu Android báo không cài đặt được vì chữ ký khác, gỡ bản cũ rồi cài APK mới. Nếu cài đặt thành công nhưng version trong Settings vẫn cũ, thường đang cài nhầm artifact cũ hoặc workflow chưa chọn source v2.3.

## Tính năng và giới hạn
Có MODULES, PACKS và SETTINGS; tìm module theo nhóm; Floating Click Hub; tìm kiếm pack; xuất/mở 20 pack; tùy chọn mở Minecraft và đặt lại lựa chọn. Các thao tác pack vẫn cần Activate trong Minecraft. Freelook, minimap thời gian thực, Time Changer, Backups và Auto Sprint chưa có tích hợp runtime thật.
