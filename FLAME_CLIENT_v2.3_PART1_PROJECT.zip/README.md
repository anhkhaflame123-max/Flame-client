# FLAME CLIENT v2.3 — ClickGUI + Pack Library (Android source)

FLAME CLIENT là ứng dụng đồng hành cho Minecraft Bedrock / PE trên Android, dùng giao diện đen–đỏ–cam theo phong cách PvP. Bản này làm mới trải nghiệm ứng dụng và quy trình build; **không phải client inject/hook vào tiến trình Minecraft**.

## Điểm mới ở v2.3

- Tăng `versionCode` lên **9** và `versionName` lên **2.3** để phân biệt APK mới với bản trước.
- Thêm biểu tượng launcher FLAME dạng adaptive icon.
- Làm rõ trạng thái module: **IMPORT** là bắt đầu xuất/mở pack; **SELECT** chỉ có nghĩa là đã chọn trong ứng dụng, không có nghĩa pack đã bật trong game.
- Thêm tìm kiếm pack trong Pack Library (tìm theo tên, mô tả hoặc tên file) và bộ đếm kết quả.
- Hiển thị tên file pack ngay trong danh sách để kiểm tra pack nào được xuất.
- Thêm nút mở Minecraft và nút đặt lại lựa chọn module trong Settings.
- Khi xuất lại pack cùng tên trên Android 10+, ứng dụng thử xóa file xuất cũ trước để tránh nhiều bản trùng tên trong thư mục Downloads.
- Thêm `scripts/verify_source.py` để kiểm tra phiên bản mã nguồn, catalog, đủ pack assets và tính toàn vẹn archive trước khi build.
- Workflow chỉ build mã nguồn **v2.3**; không fallback âm thầm về project v1.x/v2.2.
- Giữ nguyên bộ chọn Android SDK: `platform-tools`, `platforms;android-35`, `build-tools;35.0.0`.

## Cách dùng

1. Cài APK FLAME CLIENT v2.3.
2. Mở tab **MODULES**, chọn nhóm và tìm module.
3. Bấm **IMPORT** để xuất pack và yêu cầu Android mở bằng Minecraft.
4. Chờ Minecraft nhập pack. Sau đó vào **Settings > Global Resources** hoặc **Resource Packs** trong cài đặt thế giới để Activate.
5. Với file `.mcaddon`, kiểm tra cả Behavior Pack và Resource Pack nếu có.
6. Trong **PACKS**, tìm pack theo tên rồi bấm **XUẤT / MỞ PACK**. Trong **SETTINGS** có nút mở Minecraft và đặt lại lựa chọn module.

## Giới hạn kỹ thuật (cần biết)

Android không cung cấp API công khai để một ứng dụng đồng hành độc lập bật/tắt pack trong thế giới Minecraft đang chạy. Vì thế, trạng thái **SELECT** chỉ được lưu trong FLAME; muốn ngừng hiệu lực trong game, hãy Deactivate pack trong Minecraft.

Các module sau chưa được tích hợp trực tiếp vào runtime của Minecraft: Freelook/camera độc lập, minimap thời gian thực, Time Changer, Backups Manager và Auto Sprint. FPS/Ping/CPS/Zoom/Motion Blur/keystrokes và nhiều HUD dựa vào pack bên thứ ba; sự hiện diện của nút không đảm bảo add-on hoạt động với mọi bản game/API. Những chức năng chỉ có mô tả được giữ ở trạng thái chưa tích hợp thay vì giả lập bật/tắt.

Không tuyên bố tương thích 100% với Minecraft 1.26.52 vì chưa thể chạy kiểm thử game thực trên thiết bị từ môi trường build này.

## Build target

- Minecraft Bedrock / PE target: 1.26.52
- Android SDK 35 / Build Tools 35.0.0
- Java 17 / Gradle 8.9
- Application ID: `com.flameclient.android`
- App version: **2.3** (`versionCode 9`)

## Build bằng GitHub Actions trên điện thoại

1. Cách dễ tải bằng GitHub trên điện thoại: đưa **cả hai file** `FLAME_CLIENT_v2.3_PART1_PROJECT.zip` và `FLAME_CLIENT_v2.3_PART2_LARGE_PACKS.zip` vào **thư mục gốc** repository. Mỗi phần dưới giới hạn upload trình duyệt thường gặp. Hoặc dùng file đầy đủ `FLAME_CLIENT_v2.3_FLAME_REWORK.zip` nếu cách upload của bro chấp nhận file lớn hơn.
2. Thay `.github/workflows/build-apk.yml` bằng file `FLAME_CLIENT_v2.3_build-apk.yml` trong bộ tải xuống, rồi Commit Changes. Nên thêm cả hai ZIP trước khi cập nhật workflow.
3. Mở tab **Actions** và chạy workflow **Build FLAME CLIENT v2.3 APK**.
4. Chỉ tải artifact **`FLAME_CLIENT-v2.3-debug-apk`** sau khi workflow xanh.
5. Mở APK và kiểm tra mục Settings có `FLAME CLIENT v2.3 • versionCode 9`.

Nếu Android báo không cài được do chữ ký không khớp, đó là khác biệt chữ ký debug giữa các lần build: gỡ bản FLAME cũ rồi cài APK mới. Việc gỡ ứng dụng sẽ xóa các lựa chọn trong FLAME; các pack đã import vào Minecraft không bị xóa khỏi game.

**Trạng thái kiểm tra trong môi trường tạo ZIP:** đã chạy kiểm tra Python cho đủ 20 mục catalog, tất cả file pack được tham chiếu đều tồn tại và archive `.mcpack/.mcaddon` qua kiểm tra ZIP; các file XML Android đã parse thành công. Chưa build APK hoặc kiểm thử thực địa trên Samsung Galaxy A36 5G/Minecraft vì môi trường này không có Android SDK/Gradle cài sẵn.
