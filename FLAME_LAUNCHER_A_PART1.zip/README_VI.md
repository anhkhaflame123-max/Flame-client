# FLAME Launcher — Phương án A (nền tảng alpha)

## Có trong mã nguồn này
- Android app Kotlin, giao diện Flame cơ bản.
- Mở Minecraft Bedrock chính thức đã cài (`com.mojang.minecraftpe`).
- Chọn APK/ZIP bằng Storage Access Framework (không xin quyền đọc toàn bộ bộ nhớ).
- Lưu URI đã chọn bằng SharedPreferences.
- Gradle project tối giản cho GitHub Actions.

## Chưa có (không tuyên bố giả là đã hoạt động)
- Cài hoặc chạy APK Minecraft bên trong sandbox riêng.
- Multi-version isolation hoàn chỉnh.
- Native mod loader/JNI tương thích với Minecraft.
- Quản lý worlds/LevelDB và import/export pack.
- Đăng nhập/tài khoản và xử lý dữ liệu game.

Các mục trên cần phát triển và kiểm thử riêng; chọn APK bằng SAF chỉ lấy quyền đọc, không tự cài APK.

## Build
GitHub Actions dùng JDK 17 + AGP 8.7.3 + Gradle 8.9 + Android SDK 35.
Mở Actions → Android Build → Run workflow.
