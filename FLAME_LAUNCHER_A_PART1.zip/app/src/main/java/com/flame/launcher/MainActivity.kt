package com.flame.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("flame_launcher", MODE_PRIVATE) }
    private val pickApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("selected_apk_uri", uri.toString()).apply()
            status.text = "Đã chọn APK: ${displayName(uri)}\nLưu URI thành công. Chưa cài/chạy APK bên trong."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFF111111.toInt()
        val orange = 0xFFFF6A00.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
            setBackgroundColor(bg)
        }
        fun text(s: String, size: Float, color: Int = -1): TextView =
            TextView(this).apply { text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER_VERTICAL }
        layout.addView(text("🔥 FLAME LAUNCHER", 26f, orange))
        layout.addView(text("Android • Minecraft Bedrock", 14f, 0xFFCCCCCC.toInt()))
        val open = Button(this).apply { text="MỞ MINECRAFT ĐÃ CÀI" }
        open.setOnClickListener { launchInstalledMinecraft() }
        layout.addView(open, matchWrap())
        val import = Button(this).apply { text="CHỌN APK MINECRAFT (SAF)" }
        import.setOnClickListener { pickApk.launch(arrayOf("application/vnd.android.package-archive", "application/zip")) }
        layout.addView(import, matchWrap())
        val selected = prefs.getString("selected_apk_uri", null)
        status = text(if (selected == null) "Chưa chọn APK." else "Đã lưu URI APK lần trước.\n${selected}", 14f, 0xFFFFCCAA.toInt())
        status.setPadding(0,24,0,24)
        layout.addView(status)
        layout.addView(text("Quản lý phiên bản / dữ liệu cô lập / native loader: đang ở giai đoạn nền tảng. Không bật tính năng game giả bằng công tắc.", 13f, 0xFFAAAAAA.toInt()))
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin=18 }
    private fun launchInstalledMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent == null) Toast.makeText(this, "Không tìm thấy Minecraft chính thức đã cài.", Toast.LENGTH_LONG).show()
        else try { startActivity(intent) } catch (e: Exception) { Toast.makeText(this, e.message ?: "Không thể mở game", Toast.LENGTH_LONG).show() }
    }
    private fun displayName(uri: Uri): String {
        var name = "APK"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx) ?: name
        }
        return name
    }
}
