# Hướng dẫn build APK FLAME CLIENT v2.2

ZIP này là **mã nguồn**, chưa phải APK cài đặt.

## Build bằng GitHub Actions trên điện thoại

1. Tải `FLAME_CLIENT_v2.2_FLARIAL_INSPIRED.zip` và tải riêng workflow `FLAME_CLIENT_v2.2_build-apk.yml` nếu repo hiện tại còn dùng workflow cũ.
2. Tải ZIP nguồn lên trang gốc repository, giữ nguyên đúng tên file `FLAME_CLIENT_v2.2_FLARIAL_INSPIRED.zip`.
3. Trong repository, mở `.github/workflows/build-apk.yml` → bấm biểu tượng bút **Edit** → thay toàn bộ nội dung bằng file workflow v2.2 → **Commit changes**. Thao tác này quan trọng vì workflow cũ có thể build ZIP PART1 cũ trước.
4. Mở **Actions** → **Build FLAME CLIENT APK** → **Run workflow** → bấm **Run workflow** lần nữa.
5. Mở lượt chạy mới. Nếu tất cả bước màu xanh và có mục **Artifacts**, tải `FLAME_CLIENT-v2.2-debug-apk`.
6. Giải nén artifact để lấy `FLAME_CLIENT-v2.2-debug.apk`, sau đó cài trên điện thoại nếu bạn tin tưởng file do repo của mình build.

Workflow dùng Java 17, Gradle 8.9, Android SDK 35 và Build Tools 35.0.0. Lựa chọn SDK được giữ nguyên.

## Giới hạn hiện tại

- Chưa có APK được build/test thực tế từ môi trường này.
- Các công tắc trong ClickGUI lưu trạng thái trong app; tự chúng không kích hoạt module bên trong Minecraft.
- Pack cần import và bật riêng trong Minecraft.
