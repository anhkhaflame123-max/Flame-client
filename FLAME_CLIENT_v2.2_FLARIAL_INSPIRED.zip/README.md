# FLAME CLIENT v2.2 — Flarial-inspired mobile ClickGUI

This version redesigns the Android companion app around a client-style interface while retaining FLAME's black, red, and orange fire branding. It is inspired by the general organization of mod clients; it is not the Flarial application or a direct port of its proprietary runtime.

## v2.2 interface changes
- Separate top-level pages: **ClickGUI**, **Packs**, and **About**.
- Scrollable categories: **PVP**, **Sinh tồn**, **HUD**, and **Visual**.
- Search by module name or description.
- Module tiles with an icon badge, title, description, and ON/OFF control.
- Local module state persists using the same Activity preferences as previous versions.
- Module information dialog and active-module count.
- Resource packs remain in their own page to keep the ClickGUI uncluttered.
- Floating overlay launch button remains available.
- GitHub Actions workflow explicitly prefers `FLAME_CLIENT_v2.2_FLARIAL_INSPIRED.zip`, avoiding accidental builds from the old PART1 archive.

## Important limitations
This is an Android companion application and overlay, not injected into Minecraft. The module switches store their enabled state in FLAME CLIENT; they do not by themselves make features such as Freelook, live FPS/Ping/CPS counters, real-time minimap, or Motion Blur operate inside Minecraft. Resource packs must still be imported and enabled in Minecraft. Actual APK compilation and physical-device testing have not been performed in this environment.

## Build target
- Android SDK 35 / Build Tools 35.0.0
- Java 17
- Gradle 8.9
- Minecraft Bedrock / PE target: 1.26.52

The repository's GitHub Actions workflow builds a debug APK and uploads it as `FLAME_CLIENT-v2.2-debug-apk`.
