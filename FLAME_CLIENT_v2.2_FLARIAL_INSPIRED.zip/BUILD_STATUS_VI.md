# Trạng thái FLAME CLIENT v2.2

## Đã chỉnh trong mã nguồn
- Tách trang thành ClickGUI, Packs và About.
- ClickGUI có tab cuộn PVP / SINH TỒN / HUD / VISUAL.
- Có tìm kiếm module theo tên hoặc mô tả.
- Các thẻ module có huy hiệu, mô tả và nút ON/OFF.
- Trạng thái ON/OFF được lưu trong SharedPreferences của Activity để tương thích cách lưu ở bản trước.
- Số module đang ON được cập nhật khi bật/tắt.
- Trang quản lý resource pack được tách riêng.
- Workflow ưu tiên ZIP v2.2 được đặt tên rõ ràng, tránh tự chọn ZIP PART1 cũ.

## Cần nói rõ
- Chưa build APK trong môi trường này và chưa chạy thử trên Samsung Galaxy A36 5G.
- Các công tắc module là trạng thái lưu trong ứng dụng; không tự điều khiển Minecraft.
- Freelook thật, dữ liệu FPS/Ping/CPS, minimap thời gian thực, Motion Blur và các tính năng đọc dữ liệu game cần runtime hoặc tích hợp tương thích.
- Resource pack cần được import và bật trong Minecraft.

## Build target
Android SDK 35, Java 17, Gradle 8.9; mục tiêu Minecraft Bedrock / PE 1.26.52.
