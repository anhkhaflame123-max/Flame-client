# FLAME CLIENT v2.2 — build APK bằng điện thoại

## Thông số đã cấu hình
- Android Gradle Plugin: 8.7.3
- Kotlin Android plugin: 2.0.21
- Gradle trên GitHub Actions: 8.9
- Java trên GitHub Actions: 17
- Android SDK: platform 35, Build Tools 35.0.0
- Giữ các resource pack trong `app/src/main/assets/packs/`.

## Các bước trên GitHub mobile
1. Tải `FLAME_CLIENT_v2.2_FLARIAL_INSPIRED.zip` xuống điện thoại.
2. Upload file ZIP vào thư mục gốc repository và **giữ nguyên tên** `FLAME_CLIENT_v2.2_FLARIAL_INSPIRED.zip`.
3. Mở `.github/workflows/build-apk.yml` trong repository. Bấm **Edit** (biểu tượng bút), thay toàn bộ nội dung bằng file `FLAME_CLIENT_v2.2_build-apk.yml`, rồi bấm **Commit changes**. Đây là bước giúp workflow không chọn nhầm ZIP PART1 bản cũ.
4. Vào **Actions** → **Build FLAME CLIENT APK** → **Run workflow** → **Run workflow**.
5. Chọn lượt chạy mới nhất và đợi nó hoàn thành. Chỉ coi là build thành công khi job xanh và upload artifact thành công.
6. Trong **Artifacts**, tải `FLAME_CLIENT-v2.2-debug-apk`, giải nén và lấy `FLAME_CLIENT-v2.2-debug.apk`.

## Tính năng và giới hạn
Bản v2.2 có trang MODULES, PACKS, SETTINGS; tab PVP / SINH TỒN / HUD / VISUAL; tìm kiếm module; thẻ module có nút ON/OFF và nút cấu hình; trạng thái được lưu trong app. Các module chưa được tích hợp với Minecraft runtime vẫn không tự hoạt động trong game. Chưa build hoặc kiểm thử trên Samsung Galaxy A36 5G trong môi trường này.
