package com.flameclient.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 9, 12)
    private val card = Color.rgb(25, 19, 22)
    private val red = Color.rgb(255, 52, 42)
    private val orange = Color.rgb(255, 127, 38)
    private val white = Color.rgb(248, 242, 240)
    private val muted = Color.rgb(184, 165, 165)
    private val createPackFile = 7201
    private var pendingPack = ""
    private var pendingMime = "application/x-mcpack"
    private val modules = listOf(
        Module("Zoom", "Gợi ý zoom; chưa điều khiển camera Minecraft", "HUD / VISUAL"),
        Module("Freelook", "Chưa tích hợp điều khiển camera trong game", "HUD / VISUAL"),
        Module("Small Hand", "Dùng resource pack phù hợp nếu có", "PVP"),
        Module("FPS Booster", "Mẹo tối ưu và pack nhẹ; không ép FPS vượt giới hạn máy", "PERFORMANCE"),
        Module("FPS Counter", "Chỉ là trạng thái trong app, không đọc FPS Minecraft", "HUD / VISUAL"),
        Module("Ping Counter", "Chưa đọc ping từ máy chủ Minecraft", "HUD / VISUAL"),
        Module("CPS Counter", "Chưa đọc thao tác Minecraft; có thể dùng pack HUD tương thích", "HUD / VISUAL"),
        Module("Motion Blur", "Chưa áp hiệu ứng trực tiếp lên Minecraft", "HUD / VISUAL"),
        Module("Crosshair Customizer", "Bản xem trước trong app; chưa thay tâm ngắm trong game", "HUD / VISUAL"),
        Module("Minimap", "Chưa có bản đồ thời gian thực trong game", "HUD / VISUAL")
    )
    private data class Module(val name: String, val detail: String, val category: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 23) window.decorView.systemUiVisibility = 0
        render()
    }

    private fun render() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(26)); setBackgroundColor(bg) }
        page.addView(label("🔥 FLAME CLIENT", 30f, orange, true))
        page.addView(label("BEDROCK / PE 1.26.52  •  ANDROID", 11f, muted).apply { setPadding(0, dp(4), 0, dp(18)) })
        val hero = panel()
        hero.addView(label("YOUR PVP. YOUR STYLE.", 20f, white, true))
        hero.addView(label("ClickGUI • Resource Packs • Performance", 13f, orange).apply { setPadding(0, dp(6), 0, dp(14)) })
        hero.addView(action("BẬT CLICKGUI NỔI", red) { requestOverlay() })
        page.addView(hero, margin(bottom = 14))

        page.addView(section("MODULE CLICKGUI"))
        page.addView(label("Nút bên dưới lưu trạng thái bật/tắt trong ứng dụng. Các mục ghi chú chưa tích hợp không tự tác động lên Minecraft.", 12f, muted).apply { setPadding(0, 0, 0, dp(10)) })
        var lastCategory = ""
        for (module in modules) {
            if (lastCategory != module.category) {
                page.addView(label(module.category, 10f, red, true).apply { setPadding(dp(2), dp(8), 0, dp(6)) })
                lastCategory = module.category
            }
            val p = panel()
            val enabled = getPreferences(MODE_PRIVATE).getBoolean("module_${module.name}", false)
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val title = label(module.name, 15f, white, true)
            head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val toggle = action(if (enabled) "ON" else "OFF", if (enabled) orange else Color.rgb(76, 64, 65)) {
                val next = !getPreferences(MODE_PRIVATE).getBoolean("module_${module.name}", false)
                getPreferences(MODE_PRIVATE).edit().putBoolean("module_${module.name}", next).apply()
                render()
            }
            head.addView(toggle, LinearLayout.LayoutParams(dp(72), dp(42)))
            p.addView(head)
            p.addView(label(module.detail, 12f, muted).apply { setPadding(0, dp(7), 0, 0) })
            page.addView(p, margin(bottom = 8))
        }

        page.addView(section("RESOURCE PACK MANAGER"))
        page.addView(label("Xuất pack rồi mở bằng Minecraft. Sau khi nhập, hãy bật pack trong cài đặt thế giới hoặc Global Resources. Chỉ bật từng pack một để kiểm tra xung đột.", 12f, muted).apply { setPadding(0, 0, 0, dp(10)) })
        val catalog = JSONArray(assets.open("packs/catalog.json").bufferedReader().use { it.readText() })
        for (i in 0 until catalog.length()) {
            val item = catalog.getJSONObject(i)
            val file = item.getString("file")
            val p = panel()
            p.addView(label(item.getString("title"), 15f, orange, true))
            p.addView(label(item.getString("description"), 12f, muted).apply { setPadding(0, dp(5), 0, dp(10)) })
            p.addView(action("XUẤT / MỞ PACK", red) { exportPack(file, item.getString("mime")) })
            page.addView(p, margin(bottom = 9))
        }

        page.addView(section("TRẠNG THÁI TÍNH NĂNG"))
        val notes = panel()
        notes.addView(label("ĐANG CÓ: giao diện Android, nút overlay nổi, lưu trạng thái module trong app và xuất resource pack.\n\nCHƯA TÍCH HỢP TRỰC TIẾP: Freelook điều khiển camera, FPS/Ping/CPS thật trong Minecraft, Motion Blur, Lua runtime và Minimap thời gian thực. Bật nút trong app không làm các tính năng này tự hoạt động trong game.", 12f, muted))
        page.addView(notes)
        page.addView(label("FLAME CLIENT • ANDROID COMPANION • BEDROCK 1.26.52", 10f, muted).apply { gravity = Gravity.CENTER; setPadding(0, dp(18), 0, 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(page) })
    }

    private fun exportPack(assetName: String, mime: String) {
        pendingPack = assetName
        pendingMime = mime
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mime; putExtra(Intent.EXTRA_TITLE, assetName) }
        startActivityForResult(intent, createPackFile)
    }

    @Deprecated("Using startActivityForResult for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != createPackFile || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            assets.open("packs/$pendingPack").use { input ->
                contentResolver.openOutputStream(uri, "w").use { output -> requireNotNull(output) { "Không mở được file đích" }; input.copyTo(output) }
            }
            Toast.makeText(this, "Đã lưu $pendingPack. Đang mở bằng Minecraft…", Toast.LENGTH_LONG).show()
            val open = Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, pendingMime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            try { startActivity(open) } catch (_: Exception) { Toast.makeText(this, "Mở file vừa lưu trong ứng dụng Tệp nếu Minecraft chưa tự mở.", Toast.LENGTH_LONG).show() }
        } catch (e: Exception) { Toast.makeText(this, "Không thể xuất pack: ${e.message ?: "lỗi file"}", Toast.LENGTH_LONG).show() }
    }

    private fun requestOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Cho phép FLAME CLIENT hiển thị trên ứng dụng khác để dùng ClickGUI nổi.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FlameOverlayService::class.java))
        Toast.makeText(this, "Đã mở nút FLAME nổi.", Toast.LENGTH_SHORT).show()
    }
    private fun panel() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(13), dp(12), dp(13), dp(12)); background = android.graphics.drawable.GradientDrawable().apply { setColor(card); cornerRadius = dp(14).toFloat(); setStroke(dp(1), Color.rgb(86, 35, 27)) } }
    private fun section(s: String) = label(s, 12f, red, true).apply { setPadding(dp(2), dp(7), 0, dp(9)) }
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD) }
    private fun action(title: String, color: Int, click: () -> Unit) = Button(this).apply { text = title; textSize = 11f; setTextColor(Color.WHITE); background = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(9).toFloat() }; setOnClickListener { click() } }
    private fun margin(bottom: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
